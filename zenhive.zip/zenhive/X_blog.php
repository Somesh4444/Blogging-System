<?php
  include 'layout/header.php';

  $stmt = $conn->query("SELECT * FROM category");
  $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

  $category_id = 0;

  if (isset($_GET['category'])) {
      $decoded = base64_decode($_GET['category']); // Decode the full string

      // Extract the numeric part (category ID)
      $category_id = intval(substr($decoded, 10)); // Remove the first 10 random characters

      // Ensure the decoded ID is valid
      if (!is_numeric($category_id)) {
          $category_id = 0;
      }
  }

  $sql = "SELECT b.*, 
          (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
          (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
          (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
          FROM blogs b 
          WHERE b.status = 1";

  if ($category_id > 0) {
      $sql .= " AND b.cat_id = :category_id";
  }

  $sql .= " ORDER BY b.id DESC";

  $stmt = $conn->prepare($sql);

  if ($category_id > 0) {
      $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
  }

  $stmt->execute();
  $blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);


  $tb = $conn->query("SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
        (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
        (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
        FROM blogs b 
        WHERE b.status = 1 AND b.is_trending = 1
        ORDER BY b.id DESC limit 10");

  $trending_blogs = $tb->fetchAll(PDO::FETCH_ASSOC);

  $ab = $conn->query("SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
        (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
        (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
        FROM blogs b 
        WHERE b.status = 1
        ORDER BY b.id DESC limit 10");

  $latest_blogs = $ab->fetchAll(PDO::FETCH_ASSOC);

   // echo "<pre>";
   //  print_r($trending_blogs);
   //  echo "</pre>";exit;

   
   
?>


  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-9">
            <h3 class="category-title">Search Results</h3>


            <?php if (!empty($blogs)) { ?>
                <?php foreach ($blogs as $dpa) { ?>
                    <div class="d-md-flex post-entry-2 small-img">
                        <a href="single-post.html" class="me-4 thumbnail">
                            <img src="<?=SITE_URL?><?=$dpa['thumb']?>" alt="" class="img-fluid">
                        </a>
                        <div>
                            <div class="post-meta">
                                <span class="date"><?=$dpa['category_name']?></span> 
                                <span class="mx-1">&bullet;</span> 
                                <span><?= date("M jS 'y", strtotime($dpa['insert_date'])) ?></span>
                            </div>
                            <h3><a href="<?=SITE_URL?>blog-details.php?slug=<?=$dpa['urlslug']?>"><?=$dpa['heading']?></a></h3>
                            <p><?= implode(' ', array_slice(explode(' ', $dpa['description']), 0, 20)) . '...' ?></p>
                            <div class="d-flex align-items-center author">
                                <div class="photo"><img src="<?=SITE_URL?><?=$dpa['author_thumb']?>" alt="" class="img-fluid"></div>
                                <div class="name">
                                    <h3 class="m-0 p-0"><?=$dpa['author_name']?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p class="text-center text-muted">No results found.</p>
            <?php } ?>


            

            <!-- Paging -->
            <div class="text-start py-4">
              <div class="custom-pagination">
                <a href="#" class="prev">Prevous</a>
                <a href="#" class="active">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
                <a href="#">5</a>
                <a href="#" class="next">Next</a>
              </div>
            </div><!-- End Paging -->

          </div>

          <div class="col-md-3">
            <!-- ======= Sidebar ======= -->

             <div class="aside-block">
              <h3 class="aside-title">Categories</h3>
              <ul class="aside-links list-unstyled">
                <li><a href="blog.php"><i class="bi bi-chevron-right"></i>All</a></li>
                  <?php foreach ($categories as $dd) { 
                      $salt = bin2hex(random_bytes(5)); // Generating a random salt
                      $encoded_id = base64_encode($salt . $dd['id']);
                  ?>
                      <li><a href="blog.php?category=<?=$encoded_id?>"><i class="bi bi-chevron-right"></i> <?=$dd['name']?></a></li>
                  <?php } ?>
              </ul>


            </div><!-- End Categories -->

            <div class="aside-block">

              <ul class="nav nav-pills custom-tab-nav mb-4" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="pills-popular-tab" data-bs-toggle="pill" data-bs-target="#pills-popular" type="button" role="tab" aria-controls="pills-popular" aria-selected="true">Trending Posts</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="pills-trending-tab" data-bs-toggle="pill" data-bs-target="#pills-trending" type="button" role="tab" aria-controls="pills-trending" aria-selected="false">Latest Posts</button>
                </li>
               
              </ul>

              <div class="tab-content" id="pills-tabContent">

                <!-- Popular -->
               <div class="tab-pane fade show active" id="pills-popular" role="tabpanel" aria-labelledby="pills-popular-tab">
                   
                   <?php
                      foreach ($trending_blogs as $tt) {
                   ?>

                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?=$tt['category_name']?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($tt['insert_date'])) ?></span></div>
                    <h2 class="mb-2"><a href="<?=SITE_URL?>blog-details.php?slug=<?=$tt['urlslug']?>"><?=$tt['heading']?></a></h2>
                    <span class="author mb-3 d-block"><?=$tt['author_name']?></span>
                  </div>

                  <?php
                      }
                   ?>

                    
                </div>  <!-- End Popular -->

                <!-- Trending -->
                <div class="tab-pane fade" id="pills-trending" role="tabpanel" aria-labelledby="pills-trending-tab">                   

                <?php
                      foreach ($latest_blogs as $ll){
                   ?>

                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?=$ll['category_name']?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($ll['insert_date'])) ?></span></div>
                    <h2 class="mb-2"><a href="<?=SITE_URL?>blog-details.php?slug=<?=$ll['urlslug']?>"><?=$ll['heading']?></a></h2>
                    <span class="author mb-3 d-block"><?=$ll['author_name']?></span>
                  </div>

                  <?php
                      }
                   ?>                 

                </div> <!-- End Trending -->

                

              </div>
            </div>

            <div class="aside-block d-none">
              <h3 class="aside-title">Video</h3>
              <div class="video-post">
                <a href="https://www.youtube.com/watch?v=AiFfDjmd0jU" class="glightbox link-video">
                  <span class="bi-play-fill"></span>
                  <img src="<?=SITE_URL?>assets/img/post-landscape-5.jpg" alt="" class="img-fluid">
                </a>
              </div>
            </div><!-- End Video -->

           

            <div class="aside-block d-none">
              <h3 class="aside-title">Tags</h3>
              <ul class="aside-tags list-unstyled">
                <li><a href="category.html">Business</a></li>
                <li><a href="category.html">Culture</a></li>
                <li><a href="category.html">Sport</a></li>
                <li><a href="category.html">Food</a></li>
                <li><a href="category.html">Politics</a></li>
                <li><a href="category.html">Celebrity</a></li>
                <li><a href="category.html">Startups</a></li>
                <li><a href="category.html">Travel</a></li>
              </ul>
            </div><!-- End Tags -->

          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <?php
  include'layout/footer.php';
?>