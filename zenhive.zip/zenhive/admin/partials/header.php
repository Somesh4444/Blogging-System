<?php
    include '../includes/auth.php';
    include '../includes/config.php';
    require_once '../includes/functions.php';
?>
<!doctype html>
<html lang="en" class="semi-dark">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--favicon-->
	<link rel="icon" href="<?= SITE_URL ?>admin_assets/images/favicon.png" type="image/png">
	<!--plugins-->
	<link href="<?= SITE_URL ?>admin_assets/plugins/notifications/css/lobibox.min.css" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/plugins/simplebar/css/simplebar.css" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet">
	<!-- loader-->
	<link href="<?= SITE_URL ?>admin_assets/css/pace.min.css" rel="stylesheet">
	<script src="<?= SITE_URL ?>admin_assets/js/pace.min.js"></script>
	<!-- Bootstrap CSS -->
	<link href="<?= SITE_URL ?>admin_assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/css/bootstrap-extended.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/css/app.css" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/css/icons.css" rel="stylesheet">
	<link href="<?= SITE_URL ?>admin_assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet">
	<!-- Theme Style CSS -->
	<link rel="stylesheet" href="<?= SITE_URL ?>admin_assets/css/dark-theme.css">
	<link rel="stylesheet" href="<?= SITE_URL ?>admin_assets/css/semi-dark.css">
	<link rel="stylesheet" href="<?= SITE_URL ?>admin_assets/css/header-colors.css">
	<script src="<?= SITE_URL ?>admin_assets/js/ckeditor.js"></script>
	<title>ADMIN DASHBOARD</title>
<style>
	.ck-editor__editable {
		min-height: 400px;
	}

</style>
<style>
	.custom-alert {
		position: fixed;
		top: 20px;
		right: 20px;
		z-index: 1050;
		min-width: 300px;
		max-width: 400px;
		box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
		border-radius: 8px;
	}

</style>
</head>

<body>


<?php
if (isset($_SESSION['alert'])) {
    echo $_SESSION['alert'];
    unset($_SESSION['alert']);
}
?>


	<!--wrapper-->