<div class="wrapper">
		<!--sidebar wrapper -->
		<div class="sidebar-wrapper" data-simplebar="true">
			<div class="sidebar-header">
				<div>
					<img src="<?= SITE_URL ?>admin_assets/images/logo-icon.png" class="logo-icon" alt="logo icon" style="width:40px;">
				</div>
				<div>
					<h4 class="logo-text fs-5 text-uppercase">Admin Panel</h4>
				</div>
				<div class="toggle-icon ms-auto"><i class='bx bx-arrow-back'></i>   
				</div>
			 </div>
			<!--navigation-->
			<ul class="metismenu" id="menu">
			<li class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/index.php">
					<div class="parent-icon"><i class='bx bx-home-alt'></i></div>
					<div class="menu-title">Dashboard</div>
				</a>
			</li>

				 
			<li class="menu-label">Essentials</li>

			<li class="<?= basename($_SERVER['PHP_SELF']) == 'authors.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/authors.php">
					<div class="parent-icon"><i class='bx bx-group'></i>
					</div>
					<div class="menu-title">Authors</div>
				</a>
			</li>

			<li class="<?= basename($_SERVER['PHP_SELF']) == 'category.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/category.php">
					<div class="parent-icon"><i class='bx bx-category'></i>
					</div>
					<div class="menu-title">Category</div>
				</a>
			</li>


			<li class="<?= basename($_SERVER['PHP_SELF']) == 'blogs.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/blogs.php">
					<div class="parent-icon"><i class='bx bx-news'></i>
					</div>
					<div class="menu-title">Blog Lists</div>
				</a>
			</li>

			<li class="<?= basename($_SERVER['PHP_SELF']) == 'contact_leads.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/contact_leads.php">
					<div class="parent-icon"><i class='bx bx-user-check'></i>
					</div>
					<div class="menu-title">Contact Leads</div>
				</a>
			</li>

			

			<li class="menu-label">Settings</li>

			<li class="<?= basename($_SERVER['PHP_SELF']) == 'setting.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/setting.php">
					<div class="parent-icon"><i class='bx bx-cog'></i>
					</div>
					<div class="menu-title">Site Settings</div>
				</a>
			</li>

			<!-- <li class="<?= basename($_SERVER['PHP_SELF']) == 'changepass.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/changepass.php">
					<div class="parent-icon"><i class='bx bx-key'></i>
					</div>
					<div class="menu-title">Change Password</div>
				</a>
			</li> -->

			<li class="<?= basename($_SERVER['PHP_SELF']) == 'logout.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>admin/logout.php">
					<div class="parent-icon"><i class='bx bx-log-out'></i>
					</div>
					<div class="menu-title">Logout</div>
				</a>
			</li>
				
				 
				 
				 
				 
				 
				 
				 
				 
				 
				 
			</ul>
			<!--end navigation-->
		</div>
		<!--end sidebar wrapper -->
		<!--start header -->