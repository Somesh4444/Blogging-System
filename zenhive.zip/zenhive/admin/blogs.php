﻿<?php	

include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


// $data = fetch('blogs', 'status = ?', [1]);
// dump_data($_SESSION);exit;

$sql = "SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name
        FROM blogs b order by id DESC";

$stmt = $conn->prepare($sql);
$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

 

// Delete blog
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);

    $del = delete('blogs', "id = $id");

    if ($del) {
        $_SESSION['alert'] = showAlert('Blog deleted successfully!', 'success');
    } else {
        $_SESSION['alert'] = showAlert('Blog deletion failed!', 'danger'); 
    }

	echo "<script>window.location.href='blogs.php';</script>";  
}

if (isset($_GET['trending_id'])) {
    $id = intval($_GET['trending_id']);
    $current_status = intval($_GET['status']);

    $new_status = $current_status == 1 ? 0 : 1;

    $update = $conn->prepare("UPDATE blogs SET is_trending = ? WHERE id = ?");
    $update->execute([$new_status, $id]);

    $_SESSION['alert'] = showAlert('Trending status updated!', 'success');
    echo "<script>window.location.href='blogs.php';</script>";  
}
// Toggle Show/Hide
if (isset($_GET['status_id'])) {
    $id = intval($_GET['status_id']);
    $current_status = intval($_GET['status']);

    $new_status = $current_status == 1 ? 0 : 1;

    $update = $conn->prepare("UPDATE blogs SET status = ? WHERE id = ?");
    $update->execute([$new_status, $id]);

    $_SESSION['alert'] = showAlert('Visibility status updated!', 'success');
    echo "<script>window.location.href='blogs.php';</script>";  
}



?>





<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Blogs</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Blog List</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="blog_add.php" class="btn btn-primary">Add Blog</a>							 
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				 
				<h6 class="mb-0 mt-3 text-uppercase">Blog List</h6>
				<hr>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

						
							<table id="example2" class="table table-striped table-bordered pt-3">
								<thead class="table-dark">
									<tr>
										<th>Sl no.</th>
										<th>Blog Image</th>
										<th>Blog Name</th>
										<th>Blog Category</th>
										<th>Insert Date</th>
										<th>Is Trending</th>
										<th>Visibility</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>

                                <?php
                                    $i =0;
                                    foreach($data as $d){
                                    $i++;
                                    $is_trending = $d['is_trending'] == 1 ? 'Yes' : 'No';
           							$toggle_class = $d['is_trending'] == 1 ? 'btn-warning' : 'btn-secondary';
           							// Visibility Status
						            $visibility = $d['status'] == 1 ? 'Visible' : 'Hidden';
						            $visibility_class = $d['status'] == 1 ? 'btn-success' : 'btn-danger';


                                ?>

									<tr>
										<td><?=$i;?></td>
										<td><img src="<?=SITE_URL?>/<?=$d['thumb'];?>" onerror="this.onerror=null; this.src='<?=SITE_URL?>blog.jpg';" width="70"></td>
										<td><?=$d['heading'];?></td>
										<td><?=$d['category_name'];?></td>
										<td><?=$d['insert_date'];?></td>
										<td>
						                    <a href="?trending_id=<?= $d['id']; ?>&status=<?= $d['is_trending']; ?>" class="btn btn-sm <?= $toggle_class; ?>">
						                        <?= $is_trending; ?>
						                    </a>
						                </td>
						                <td>
						                    <a href="?status_id=<?= $d['id']; ?>&status=<?= $d['status']; ?>" class="btn btn-sm <?= $visibility_class; ?>">
						                        <?= $visibility; ?>
						                    </a>
						                </td>


										<td>
										<a href="blog_edit.php?id=<?= htmlspecialchars($d['id']); ?>" class="fs-5" title="Edit Blog">
											<i class="fadeIn animated bx bx-edit"></i>
										</a>

											<a href="?delete_id=<?= $d['id']; ?>" class="fs-5" onclick="return confirm('Are you sure you want to delete this blog?')"><i class="fadeIn animated bx bx-trash-alt text-danger"></i></a>
										</td>
										 
									</tr>	
                                    
                                <?php
                                    }
                                ?>

							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--end page wrapper -->














	
		
		 

<?php include 'partials/footer.php'; ?>


<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>







