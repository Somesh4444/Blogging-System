﻿<?php	

include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


$data = fetch('category');
// dump_data($_SESSION);exit;

 

 

// Delete blog
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);

    $del = delete('category', "id = $id");

    if ($del) {
        $_SESSION['alert'] = showAlert('Data deleted successfully!', 'success');
    } else {
        $_SESSION['alert'] = showAlert('Data deletion failed!', 'danger'); 
    }

	echo "<script>window.location.href='category.php';</script>";  
}

	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['author_id'], $_POST['new_status'])) {
	    $id = intval($_POST['author_id']); 
	    $new_status = intval($_POST['new_status']); 

	    $stmt = $conn->prepare("UPDATE category SET status = ? WHERE id = ?");
	    $stmt->execute([$new_status, $id]);

	    $_SESSION['alert'] = showAlert('Status Updated successfully!', 'success');
	    echo "<script>window.location.href='category.php';</script>";  
	}



?>





<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Category</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Category List</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="category_add.php" class="btn btn-primary">Add Category</a>							 
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				 
				<h6 class="mb-0 mt-3 text-uppercase">Category List</h6>
				<hr>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

						
							<table id="example2" class="table table-striped table-bordered pt-3">
								<thead class="table-dark">
									<tr>
										<th>Sl no.</th>
										<th>Name</th>
										<th>Insert Date</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>

                                <?php
                                    $i =0;
                                    foreach($data as $d){
                                    $i++;

                                ?>

									<tr>
										<td><?=$i;?></td>
										<td><?=$d['name'];?></td>
										<td><?=$d['created_on'];?></td>

										<td>
											<a href="?delete_id=<?= $d['id']; ?>" class="fs-5" onclick="return confirm('Are you sure you want to delete this?')"><i class="fadeIn animated bx bx-trash-alt text-danger"></i></a>
										</td>
										 
									</tr>	
                                    
                                <?php
                                    }
                                ?>

							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--end page wrapper -->














	
		
		 

<?php include 'partials/footer.php'; ?>


<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>


 







