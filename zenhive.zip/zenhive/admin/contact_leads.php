﻿<?php	
include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


$data = fetch('contact_leads', 'status = ?', [1]);
// dump_data($data);exit;

// Delete blog
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);

    $del = delete('contact_leads', "id = $id");

    if ($del) {
        $_SESSION['alert'] = showAlert('Contact lead deleted successfully!', 'success');
    } else {
        $_SESSION['alert'] = showAlert('Contact lead deletion failed!', 'danger'); 
    }

	echo "<script>window.location.href='contact_leads.php';</script>";  
}


?>







<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				 
				<!--end breadcrumb-->
				 
				<h6 class="mb-0 mt-3 text-uppercase">Contact Leads List</h6>
				<hr>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

						
							<table id="example2" class="table table-striped table-bordered pt-3">
								<thead class="table-dark">
									<tr>
										<th>Sl No.</th>
										<th>Name</th>
										<th>Email</th>
										<th>Subject</th>
										<th>Message</th>
										<th>Date</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>

                                <?php
                                    $i =0;
                                    foreach($data as $d){
                                    $i++
                                ?>

									<tr>
										<td><?=$i;?></td>
                                        <td><?=$d['name'];?></td>
                                        <td><?=$d['email'];?></td>
                                        <td><?=$d['subject'];?></td>
                                        <td title="<?=$d['message'];?>"><?= implode(" ", array_slice(explode(" ", $d['message']), 0, 15)) . '...'; ?></td>
										<td><?= date("F j, Y", strtotime($d['created_on'])); ?></td>
										<td>
											<a href="?delete_id=<?= $d['id']; ?>" class="fs-5" onclick="return confirm('Are you sure you want to delete this contact lead?')"><i class="fadeIn animated bx bx-trash-alt text-danger"></i></a>
										</td>
										 
									</tr>	
                                    
                                <?php
                                    }
                                ?>

							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--end page wrapper -->














	
		
		 

<?php include 'partials/footer.php'; ?>


<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>







