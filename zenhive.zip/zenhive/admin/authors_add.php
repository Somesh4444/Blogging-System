﻿<?php	
include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'fname' => sanitize($_POST['fname']),
        'mname' => sanitize($_POST['mname']),
        'lname' => sanitize($_POST['lname']),
        'email' => sanitize($_POST['email']),
        'phone' => sanitize($_POST['phone']),
        'password' => md5("author123"), 
        'created_on' => date('Y-m-d H:i:s'),
        'created_by' => $_SESSION['admin_id']
    ];

    $image = uploadImage($_FILES['files']);
    $data['thumb'] = $image ? $image : '';

    // dump_data($data);exit;


    $r = insert('authors', $data);
    if ($r) {
		$_SESSION['alert'] = showAlert('Data inserted successfully!', 'success');	
        echo "<script>window.location.href='authors.php';</script>";
    } else {
		$_SESSION['alert'] = showAlert('Data insertion failed!', 'danger'); 
        echo "<script>window.location.href='authors_add.php';</script>";
    }
}



?>




<!--start page wrapper -->
<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Authors</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Authors Form</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="authors.php" class="btn btn-primary">Back To List</a>					 
							 
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-10 mx-auto">
						
						<div class="card">
							<div class="card-body p-4">
								<h5 class="mb-4">Add Author</h5>
								<form method="post" enctype="multipart/form-data" class="row g-3">
									<div class="col-md-4">
										<label class="form-label">First Name</label>
										<input type="text" class="form-control" name="fname" placeholder="First Name">
									</div>

									<div class="col-md-4">
										<label class="form-label">Middle Name</label>
										<input type="text" class="form-control" name="mname" placeholder="Middle Name">
									</div>

									<div class="col-md-4">
										<label class="form-label">Last Name</label>
										<input type="text" class="form-control" name="lname" placeholder="Last Name">
									</div>

									<div class="col-md-6">
										<label class="form-label">Email</label>
										<input type="email" class="form-control" name="email" placeholder="Enter Email">
									</div>

									<div class="col-md-6">
										<label class="form-label">Phone No.</label>
										<input type="text" class="form-control" name="phone" placeholder="Enter Phone Number">
									</div>

									 

									<div class="col-xl-6 me-auto">
										<h6 class="mb-0 text-uppercase">Choose an Image (450 x 450)</h6>	
										<hr>
										<div class="card">
											<div class="card-body text-center">
												<!-- Image Preview -->
												<div id="image-preview" style="width: 100%; height: 200px; border: 2px dashed #ccc; display: flex; align-items: center; justify-content: center; overflow: hidden;">
													<p style="color: #888;">No image selected</p>
												</div>

												<!-- File Input -->
												<input id="image-upload" type="file" name="files" accept=".jpg, .png, image/jpeg, image/png" class="form-control mt-3">
											</div>
										</div>
									</div>

									<div class="col-md-12">
										<div class="d-md-flex d-grid align-items-center gap-3">
											<button type="submit" class="btn btn-primary px-4">Submit</button>
											<button type="reset" class="btn btn-light px-4">Reset</button>
										</div>
									</div>
								</form>
							</div>
						</div>

						 


					</div>
				</div>
				<!--end row-->

 




			</div>
		</div>
		<!--end page wrapper -->









	
		
		 

<?php include 'partials/footer.php'; ?>







