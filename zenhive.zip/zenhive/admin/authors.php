﻿<?php	

include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


$data = fetch('authors');
// dump_data($_SESSION);exit;

 

 

// Delete blog
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);

    $del = delete('authors', "id = $id");

    if ($del) {
        $_SESSION['alert'] = showAlert('Blog deleted successfully!', 'success');
    } else {
        $_SESSION['alert'] = showAlert('Blog deletion failed!', 'danger'); 
    }

	echo "<script>window.location.href='authors.php';</script>";  
}

	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['author_id'], $_POST['new_status'])) {
	    $id = intval($_POST['author_id']); 
	    $new_status = intval($_POST['new_status']); 

	    $stmt = $conn->prepare("UPDATE authors SET status = ? WHERE id = ?");
	    $stmt->execute([$new_status, $id]);

	    $_SESSION['alert'] = showAlert('Status Updated successfully!', 'success');
	    echo "<script>window.location.href='authors.php';</script>";  
	}



?>





<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Authors</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Authors List</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="authors_add.php" class="btn btn-primary">Add Author</a>							 
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				 
				<h6 class="mb-0 mt-3 text-uppercase">Authors List</h6>
				<hr>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

						
							<table id="example2" class="table table-striped table-bordered pt-3">
								<thead class="table-dark">
									<tr>
										<th>Sl no.</th>
										<th>Image</th>
										<th>Name</th>
										<th>Email</th>
										<th>Phone</th>
										<th>Insert Date</th>
										<th>Status</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>

                                <?php
                                    $i =0;
                                    foreach($data as $d){
                                    $i++;
                                    $statusClass = ($d['status'] == 1) ? 'btn-success' : 'btn-danger';
						            $statusText = ($d['status'] == 1) ? 'Active' : 'Inactive';
						            $newStatus = ($d['status'] == 1) ? 0 : 1;

                                ?>

									<tr>
										<td><?=$i;?></td>
										<td>
										    <img src="<?=SITE_URL?>/<?=$d['thumb'];?>" width="70" 
										         onerror="this.onerror=null; this.src='<?=SITE_URL?>user.png';">
										</td>

										<td><?=$d['fname'];?> <?=$d['mname'];?> <?=$d['lname'];?></td>
										<td><?=$d['email'];?></td>
										<td><?=$d['phone'];?></td>
										<td><?=$d['created_on'];?></td>

										<td>
							                <form method="POST">
							                    <input type="hidden" name="author_id" value="<?= $d['id']; ?>">
							                    <input type="hidden" name="new_status" value="<?= $newStatus; ?>">

							                    <button type="submit" class="btn btn-sm <?= $statusClass; ?>"
							                            onclick="return confirm('Are you sure you want to <?= ($newStatus == 1) ? 'activate' : 'deactivate'; ?> this author?')">
							                        <?= $statusText; ?>
							                    </button>
							                </form>
							            </td>




										<td>
										<a href="authors_edit.php?id=<?= htmlspecialchars($d['id']); ?>" class="fs-5" title="Edit Blog">
											<i class="fadeIn animated bx bx-edit"></i>
										</a>

											<a href="?delete_id=<?= $d['id']; ?>" class="fs-5" onclick="return confirm('Are you sure you want to delete this?')"><i class="fadeIn animated bx bx-trash-alt text-danger"></i></a>
										</td>
										 
									</tr>	
                                    
                                <?php
                                    }
                                ?>

							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--end page wrapper -->














	
		
		 

<?php include 'partials/footer.php'; ?>


<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>


 







