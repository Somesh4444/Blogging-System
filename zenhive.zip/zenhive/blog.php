<?php
  include 'layout/header.php';

  // Fetch categories
  $stmt = $conn->query("SELECT * FROM category");
  $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // Default values
  $category_id = 0;
  $category_name = "";
  $blog_count = 0;
  $blogs_per_page = 9;

  // Get total blog count where status = 1
  $total_stmt = $conn->query("SELECT COUNT(*) AS total_blogs FROM blogs WHERE status = 1");
  $total_result = $total_stmt->fetch(PDO::FETCH_ASSOC);
  $total_blogs = $total_result['total_blogs'];

  // Get current page number from URL, default is 1
  $current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
  $offset = ($current_page - 1) * $blogs_per_page;

  // Handle category filtering
  if (isset($_GET['category'])) {
      $decoded = base64_decode($_GET['category']); 
      $category_id = intval(substr($decoded, 10));

      if ($category_id > 0) {
          $stmt = $conn->prepare("SELECT name FROM category WHERE id = ?");
          $stmt->execute([$category_id]);
          $category = $stmt->fetch(PDO::FETCH_ASSOC);
          $category_name = $category ? $category['name'] : "Unknown Category";

          // Get count for category blogs
          $count_stmt = $conn->prepare("SELECT COUNT(*) AS category_blogs FROM blogs WHERE status = 1 AND cat_id = ?");
          $count_stmt->execute([$category_id]);
          $count_result = $count_stmt->fetch(PDO::FETCH_ASSOC);
          $blog_count = $count_result['category_blogs'];
      } else {
          $category_id = 0;
      }
  }

  // Handle search
  $search_query = "";
  if (isset($_GET['q']) && !empty($_GET['q'])) {
      $search_query = trim($_GET['q']);
  }

  // Construct SQL query
  $sql = "SELECT b.*, 
          (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
          (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
          (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
          FROM blogs b 
          WHERE b.status = 1";

  if ($category_id > 0) {
      $sql .= " AND b.cat_id = :category_id";
  }

  if (!empty($search_query)) {
      $sql .= " AND (b.heading LIKE :search OR b.description LIKE :search)";
  }

  $sql .= " ORDER BY b.id DESC LIMIT :limit OFFSET :offset";

  $stmt = $conn->prepare($sql);

  if ($category_id > 0) {
      $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
  }

  if (!empty($search_query)) {
      $search_param = "%" . $search_query . "%";
      $stmt->bindParam(':search', $search_param, PDO::PARAM_STR);
  }

$stmt->bindParam(':limit', $blogs_per_page, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate total pages
$total_pages = ceil(($category_id > 0 ? $blog_count : $total_blogs) / $blogs_per_page);

// Fetch trending blogs
$tb = $conn->query("SELECT b.*, 
      (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
      (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
      (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
      FROM blogs b 
      WHERE b.status = 1 AND b.is_trending = 1
      ORDER BY b.id DESC LIMIT 10");
$trending_blogs = $tb->fetchAll(PDO::FETCH_ASSOC);

// Fetch latest blogs
$ab = $conn->query("SELECT b.*, 
      (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
      (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
      (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
      FROM blogs b 
      WHERE b.status = 1
      ORDER BY b.id DESC LIMIT 10");
$latest_blogs = $ab->fetchAll(PDO::FETCH_ASSOC);


?>

  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-9">
            <?php if (!empty($search_query)) { ?>
                <h3 class="category-title">Search Results for "<?= htmlspecialchars($search_query); ?>"</h3>
            <?php } elseif ($category_id > 0) { ?>
                <h3 class="category-title">Results for "<?= htmlspecialchars($category_name); ?> (<?= $blog_count; ?>)"</h3>
            <?php } else { ?>
                <h3 class="category-title">All Published Articles (<?= $total_blogs; ?>)</h3>
            <?php } ?>



            <?php if (!empty($blogs)) { ?>
                <?php foreach ($blogs as $dpa) { ?>
                    <div class="d-md-flex post-entry-2 small-img">
                        <a href="<?=SITE_URL?>blog-details.php?slug=<?=$dpa['urlslug']?>" class="me-4 thumbnail">
                            <img src="<?=SITE_URL?><?=$dpa['thumb']?>" onerror="this.onerror=null; this.src='<?=SITE_URL?>blog.jpg';" alt="" class="img-fluid">
                        </a>
                        <div>
                            <div class="post-meta mt-3 mt-lg-0">
                                <span class="date"><?=$dpa['category_name']?></span> 
                                <span class="mx-1">&bullet;</span> 
                                <span><?= date("M jS 'y", strtotime($dpa['insert_date'])) ?></span>
                            </div>
                            <h3><a href="<?=SITE_URL?>blog-details.php?slug=<?=$dpa['urlslug']?>"><?=$dpa['heading']?></a></h3>
                            <p><?= implode(' ', array_slice(explode(' ', $dpa['description']), 0, 20)) . '...' ?></p>
                            <div class="d-flex align-items-center author">
                                <div class="photo"><img src="<?=SITE_URL?><?=$dpa['author_thumb']?>" alt="" class="img-fluid"></div>
                                <div class="name">
                                    <h3 class="m-0 p-0"><?=$dpa['author_name']?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <p class="text-center text-muted">No results found.</p>
            <?php } ?>


            

             <!-- Pagination -->
            <div class="text-start py-4">
                <div class="custom-pagination">
                    <?php if ($current_page > 1): ?>
                        <a href="?page=<?= $current_page - 1 ?><?= $category_id ? '&category=' . $_GET['category'] : '' ?>" class="prev">Previous</a>
                    <?php endif; ?>

                    <?php
                      $visible_pages = 5;
                      $start_page = max(1, $current_page - floor($visible_pages / 2));
                      $end_page = min($total_pages, $start_page + $visible_pages - 1);

                      // Ensure at least 5 pages are shown when possible
                      if ($end_page - $start_page + 1 < $visible_pages) {
                          $start_page = max(1, $end_page - $visible_pages + 1);
                      }

                      // Show first page always
                      if ($start_page > 1) {
                          echo '<a href="?page=1' . ($category_id ? '&category=' . $_GET['category'] : '') . '">1</a>';
                          if ($start_page > 2) echo '<span>...</span>';
                      }

                      // Show range of pages
                      for ($i = $start_page; $i <= $end_page; $i++): ?>
                          <a href="?page=<?= $i ?><?= $category_id ? '&category=' . $_GET['category'] : '' ?>" class="<?= ($i == $current_page) ? 'active' : '' ?>">
                              <?= $i ?>
                          </a>
                      <?php endfor;

                      // Show last page always
                      if ($end_page < $total_pages) {
                          if ($end_page < $total_pages - 1) echo '<span>...</span>';
                          echo '<a href="?page=' . $total_pages . ($category_id ? '&category=' . $_GET['category'] : '') . '">' . $total_pages . '</a>';
                      }
                    ?>

                    <?php if ($current_page < $total_pages): ?>
                        <a href="?page=<?= $current_page + 1 ?><?= $category_id ? '&category=' . $_GET['category'] : '' ?>" class="next">Next</a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- End Pagination -->



          </div>

          <div class="col-md-3">
            <!-- ======= Sidebar ======= -->

             <div class="aside-block">
              <h3 class="aside-title">Categories</h3>
              <ul class="aside-links list-unstyled">
                <li><a href="blog.php"><i class="bi bi-chevron-right"></i>All</a></li>
                  <?php foreach ($categories as $dd) { 
                      $salt = bin2hex(random_bytes(5)); // Generating a random salt
                      $encoded_id = base64_encode($salt . $dd['id']);
                  ?>
                      <li><a href="blog.php?category=<?=$encoded_id?>"><i class="bi bi-chevron-right"></i> <?=$dd['name']?></a></li>
                  <?php } ?>
              </ul>


            </div><!-- End Categories -->

            <div class="aside-block">

              <ul class="nav nav-pills custom-tab-nav mb-4" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="pills-popular-tab" data-bs-toggle="pill" data-bs-target="#pills-popular" type="button" role="tab" aria-controls="pills-popular" aria-selected="true">Trending Posts</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="pills-trending-tab" data-bs-toggle="pill" data-bs-target="#pills-trending" type="button" role="tab" aria-controls="pills-trending" aria-selected="false">Latest Posts</button>
                </li>
               
              </ul>

              <div class="tab-content" id="pills-tabContent">

                <!-- Popular -->
               <div class="tab-pane fade show active" id="pills-popular" role="tabpanel" aria-labelledby="pills-popular-tab">
                   
                   <?php
                      foreach ($trending_blogs as $tt) {
                   ?>

                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?=$tt['category_name']?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($tt['insert_date'])) ?></span></div>
                    <h2 class="mb-2"><a href="<?=SITE_URL?>blog-details.php?slug=<?=$tt['urlslug']?>"><?=$tt['heading']?></a></h2>
                    <span class="author mb-3 d-block"><?=$tt['author_name']?></span>
                  </div>

                  <?php
                      }
                   ?>

                    
                </div>  <!-- End Popular -->

                <!-- Trending -->
                <div class="tab-pane fade" id="pills-trending" role="tabpanel" aria-labelledby="pills-trending-tab">                   

                <?php
                      foreach ($latest_blogs as $ll){
                   ?>

                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?=$ll['category_name']?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($ll['insert_date'])) ?></span></div>
                    <h2 class="mb-2"><a href="<?=SITE_URL?>blog-details.php?slug=<?=$ll['urlslug']?>"><?=$ll['heading']?></a></h2>
                    <span class="author mb-3 d-block"><?=$ll['author_name']?></span>
                  </div>

                  <?php
                      }
                   ?>                 

                </div> <!-- End Trending -->

                

              </div>
            </div>

            <div class="aside-block d-none">
              <h3 class="aside-title">Video</h3>
              <div class="video-post">
                <a href="https://www.youtube.com/watch?v=AiFfDjmd0jU" class="glightbox link-video">
                  <span class="bi-play-fill"></span>
                  <img src="<?=SITE_URL?>assets/img/post-landscape-5.jpg" alt="" class="img-fluid">
                </a>
              </div>
            </div><!-- End Video -->

           

            <div class="aside-block d-none">
              <h3 class="aside-title">Tags</h3>
              <ul class="aside-tags list-unstyled">
                <li><a href="category.html">Business</a></li>
                <li><a href="category.html">Culture</a></li>
                <li><a href="category.html">Sport</a></li>
                <li><a href="category.html">Food</a></li>
                <li><a href="category.html">Politics</a></li>
                <li><a href="category.html">Celebrity</a></li>
                <li><a href="category.html">Startups</a></li>
                <li><a href="category.html">Travel</a></li>
              </ul>
            </div><!-- End Tags -->

          </div>

        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <?php
  include'layout/footer.php';
?>