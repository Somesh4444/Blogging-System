﻿<?php	

include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


// $data = fetch('blogs', 'status = ?', [1]);
// dump_data($_SESSION);exit;

$sql = "SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name
        FROM blogs b 
        WHERE b.author_id = :author_id
        ORDER BY b.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bindParam(':author_id', $_SESSION['author_id'], PDO::PARAM_INT);
$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);


 

// Delete blog
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);

    $del = delete('blogs', "id = $id");

    if ($del) {
        $_SESSION['alert'] = showAlert('Blog deleted successfully!', 'success');
    } else {
        $_SESSION['alert'] = showAlert('Blog deletion failed!', 'danger'); 
    }

	echo "<script>window.location.href='blogs.php';</script>";  
}


?>





<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Blogs</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Blog List</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="blog_add.php" class="btn btn-primary">Add Blog</a>							 
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				 
				<h6 class="mb-0 mt-3 text-uppercase">Blog List</h6>
				<hr>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

						
							<table id="example2" class="table table-striped table-bordered pt-3">
								<thead class="table-dark">
									<tr>
										<th>Sl no.</th>
										<th>Blog Image</th>
										<th>Blog Name</th>
										<th>Blog Category</th>
										<th>Insert Date</th>
										<th>Comments</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>

                                <?php
                                    $i =0;
                                    foreach($data as $d){
                                    $i++
                                ?>

									<tr>
										<td><?=$i;?></td>
										<td><img src="<?=SITE_URL?>/<?=$d['thumb'];?>" onerror="this.onerror=null; this.src='<?=SITE_URL?>blog.jpg';" width="70"></td>
										<td><?=$d['heading'];?></td>
										<td><?=$d['category_name'];?></td>
										<td><?=$d['insert_date'];?></td>

										<td>
											<?php
											    // Fetch comment count for each blog post
											    $comment_count_stmt = $conn->prepare("SELECT COUNT(*) AS total FROM comments WHERE blog_id = :blog_id");
											    $comment_count_stmt->bindParam(':blog_id', $d['id'], PDO::PARAM_INT);
											    $comment_count_stmt->execute();
											    $comment_count = $comment_count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
											    ?>
											    
											    <a href="blog_comments.php?id=<?= $d['id']; ?>" style="font-size: 16px;" title="View Comments">
											        <i class="fadeIn animated bx bx-comment-detail"></i>
											        Comments <span>(<?= $comment_count ?>)</span>
											    </a>
										</td>


										<td>

										<a href="blog_edit.php?id=<?= htmlspecialchars($d['id']); ?>" class="fs-5" title="Edit Blog">
											<i class="fadeIn animated bx bx-edit"></i>
										</a>

											<a href="?delete_id=<?= $d['id']; ?>" class="fs-5" onclick="return confirm('Are you sure you want to delete this blog?')"><i class="fadeIn animated bx bx-trash-alt text-danger"></i></a>


										</td>


										 
									</tr>	
                                    
                                <?php
                                    }
                                ?>

							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--end page wrapper -->














	
		
		 

<?php include 'partials/footer.php'; ?>


<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>







