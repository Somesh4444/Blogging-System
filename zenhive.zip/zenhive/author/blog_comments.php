﻿<?php	

include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


// $data = fetch('blogs', 'status = ?', [1]);
// dump_data($_SESSION);exit;

 if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $blog_id = $_GET['id'];

    // Fetch comments for this blog
    $comments_stmt = $conn->prepare("SELECT * FROM comments WHERE blog_id = :blog_id ORDER BY created_at DESC");
    $comments_stmt->bindParam(':blog_id', $blog_id, PDO::PARAM_INT);
    $comments_stmt->execute();
    $comments = $comments_stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    die("Invalid Blog ID.");
}

if (isset($_GET['delete_comment']) && is_numeric($_GET['delete_comment'])) {
    $comment_id = $_GET['delete_comment'];

    $delete_stmt = $conn->prepare("DELETE FROM comments WHERE id = :comment_id");
    $delete_stmt->bindParam(':comment_id', $comment_id, PDO::PARAM_INT);
    
    if ($delete_stmt->execute()) {
        echo "<script>alert('Comment deleted successfully.'); window.location.href='blog_comments.php?id=$blog_id';</script>";
    } else {
        echo "<script>alert('Failed to delete comment.');</script>";
    }
}
?>



 // dump_data($comments);exit;

 


?>





<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Comments</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Comments List</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="blogs.php" class="btn btn-primary">Back To Blogs</a>							 
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				 
				<h6 class="mb-0 mt-3 text-uppercase">Comments List</h6>
				<hr>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

						
							<table id="example2" class="table table-striped table-bordered pt-3">
								<thead class="table-dark">
									<tr>
										<th>Sl no.</th>
										<th>Date</th>
										<th>Name</th>
										<th>Email</th>
										<th>Comments</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody>

                                <?php
                                    $i =0;
                                    foreach($comments as $d){
                                    $i++
                                ?>

									<tr>
										<td><?=$i;?></td> 
										<td>
										    <span class="time-ago" data-time="<?= $d['created_at']; ?>">
										        <?= $d['created_at']; ?>  <!-- Default date (replaced by JS) -->
										    </span>
										</td>

										<td><?=$d['name'];?></td>
										<td><?=$d['email'];?></td>
										<td title="<?=$d['message'];?>"><?= mb_strimwidth(htmlspecialchars($d['message']), 0, 40, "..."); ?></td>							 							 


										<td>

											<a href="?delete_comment=<?= $d['id'] ?>&id=<?= $blog_id ?>" class="btn btn-sm btn-danger"
                           						onclick="return confirm('Are you sure you want to delete this comment?');">Delete</a>


										</td>


										 
									</tr>	
                                    
                                <?php
                                    }
                                ?>

							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--end page wrapper -->














	
		
		 

<?php include 'partials/footer.php'; ?>


<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	<script>
		$(document).ready(function() {
			var table = $('#example2').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'pdf', 'print']
			} );
		 
			table.buttons().container()
				.appendTo( '#example2_wrapper .col-md-6:eq(0)' );
		} );
	</script>





	<script type="text/javascript">
		function timeAgo(datetime) {
	    let time = new Date(datetime);
	    let now = new Date();
	    let diffInSeconds = Math.floor((now - time) / 1000);

	    let timeUnits = [
	        { unit: "year", seconds: 31556926 },
	        { unit: "month", seconds: 2629743 },
	        { unit: "week", seconds: 604800 },
	        { unit: "day", seconds: 86400 },
	        { unit: "hour", seconds: 3600 },
	        { unit: "minute", seconds: 60 },
	        { unit: "second", seconds: 1 }
	    ];

	    for (let i = 0; i < timeUnits.length; i++) {
	        let elapsed = Math.floor(diffInSeconds / timeUnits[i].seconds);
	        if (elapsed > 0) {
	            return elapsed + " " + timeUnits[i].unit + (elapsed > 1 ? "s" : "") + " ago";
	        }
	    }
	    return "Just now";
	}

	</script>

	<script>
	document.addEventListener("DOMContentLoaded", function () {
	    let elements = document.querySelectorAll(".time-ago");
	    elements.forEach(function (el) {
	        let datetime = el.getAttribute("data-time");
	        el.innerText = timeAgo(datetime);
	    });
	});
	</script>