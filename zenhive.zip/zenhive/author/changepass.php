﻿<?php	
include('partials/header.php'); 
include('partials/left_nav.php'); 
include('partials/top_bar.php'); 
require_once '../includes/functions.php';


if (!isset($_SESSION['author_id'])) {
    echo "<script>window.location.href='login.php';</script>";
    exit;
}

$author_id = $_SESSION['author_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = md5($_POST['current_password']);
    $new_password = md5($_POST['new_password']);
    $confirm_password = md5($_POST['confirm_password']);

    // Fetch current password from DB
    $stmt = $conn->prepare("SELECT password FROM authors WHERE id = :author_id");
    $stmt->execute(['author_id' => $author_id]);
    $author = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$author || $author['password'] !== $current_password) {
        $_SESSION['alert'] = showAlert('Current password is incorrect!', 'danger');
        echo "<script>window.location.href='changepass.php';</script>";
        exit;
    }

    if ($new_password !== $confirm_password) {
        $_SESSION['alert'] = showAlert('New passwords do not match!', 'danger');
        echo "<script>window.location.href='changepass.php';</script>";
        exit;
    }

    // Update password
    $update_stmt = $conn->prepare("UPDATE authors SET password = :new_password WHERE id = :author_id");
    $updated = $update_stmt->execute([
        'new_password' => $new_password,
        'author_id' => $author_id
    ]);

    if ($updated) {
        $_SESSION['alert'] = showAlert('Password updated successfully!', 'success');
    } else {
        $_SESSION['alert'] = showAlert('Error updating password!', 'danger');
    }

    echo "<script>window.location.href='changepass.php';</script>";
    exit;
}



 



?>




<!--start page wrapper -->
<div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<!-- <div class="breadcrumb-title pe-3">Change Password</div> -->
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Change Your Password</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="index.php" class="btn btn-primary">Back To Home</a>					 
							 
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
				<div class="row">
					<div class="col-xl-10 mx-auto">
						
						<div class="card">
							<div class="card-body p-4">
								<h5 class="mb-4">Change Password</h5>
								<form method="post" class="row g-3">
								    <div class="col-md-12">
								        <label for="current_password" class="form-label">Current Password</label>
								        <input type="password" class="form-control" name="current_password" required>
								    </div>

								    <div class="col-md-12">
								        <label for="new_password" class="form-label">New Password</label>
								        <input type="password" class="form-control" name="new_password" required>
								    </div>

								    <div class="col-md-12">
								        <label for="confirm_password" class="form-label">Confirm New Password</label>
								        <input type="password" class="form-control" name="confirm_password" required>
								    </div>

								    <div class="col-md-12">
								        <div class="d-md-flex d-grid align-items-center gap-3">
								            <button type="submit" name="change_password" class="btn btn-primary px-4">Change Password</button>
								        </div>
								    </div>
								</form>
	

							</div>
						</div>

						 


					</div>
				</div>
				<!--end row-->

 




			</div>
		</div>
		<!--end page wrapper -->









	
		
		 

<?php include 'partials/footer.php'; ?>







