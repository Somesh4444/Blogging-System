<?php
session_start();
require_once '../includes/functions.php';

// Redirect if already logged in
if (isset($_SESSION['author_id'])) {
    header('Location: index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = md5($_POST['password']); 

    $author = fetch('authors', "email = '$email' AND password = '$password'");

    if ($author) {
        $_SESSION['author_id'] = $author[0]['id'];
        $_SESSION['author_email'] = $author[0]['email'];
        $_SESSION['author_name'] = $author[0]['fname'] . ' ' . $author[0]['mname'] . ' ' . $author[0]['lname'];
        $_SESSION['author_thumb'] = $author[0]['thumb'];
        $_SESSION['author_phone'] = $author[0]['phone'];
        $_SESSION['author_created_on'] = $author[0]['created_on'];
        $_SESSION['author_created_by'] = $author[0]['created_by'];
        $_SESSION['author_status'] = $author[0]['status'];
        header('Location: index.php');
        exit();
    } else {
        $error = "Invalid email or password!";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Author Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body, html {
            height: 100%;
            width: 100%;
        }

        .container-fluid {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .row {
            width: 100%;
            height: 100%;
        }

        .login-image {
            background: url('https://c0.wallpaperflare.com/preview/912/739/608/black-coffee-break-break-time-brewed-coffee.jpg') center/cover no-repeat;
            height: 100vh;
        }

        .login-form {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: #f1f1f1;
            padding: 40px;
        }

        .login-card {
            width: 100%;
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 768px) {
            .login-image {
                display: none;
            }
        }
    </style>
</head>
<body class="m-0 p-0">

<div class="container-fluid mx-0">
    <div class="row">
        <!-- Left Side Image -->
        <div class="col-md-8 login-image d-none d-md-block"></div>

        <!-- Right Side Login Form -->
        <div class="col-md-4 login-form">
            <div class="login-card">
                <h3 class="text-center mb-3">Author Login</h3>
                <?php if (isset($error)) echo "<p class='text-danger text-center'>$error</p>"; ?>
                <form action="login.php" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
