﻿<?php	
include('partials/header.php'); 
include('partials/left_nav.php'); 

// echo '<pre>';
// print_r($_SESSION);
// echo '</pre>';exit();


include('partials/top_bar.php'); 
?>

<style type="text/css">
	 

</style>
	
		
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				 

				 

				 

				 <div class="card radius-10 p-5" style="height: 250px;">
					 
                    <h2>Hello <?= $_SESSION['author_name']; ?> Welcome Back!! ✨</h2>    

                  <h2 id="quote" style="font-size: 22px; font-style: italic; font-weight: bold;	background: linear-gradient(90deg, #ff416c, #ff4b2b, #ff9800, #ffeb3b); -webkit-background-clip: text;-webkit-text-fill-color: transparent;display: inline-block;"></h2>


				</div>

				 

					 


					 
			</div>
		</div>
		<!--end page wrapper -->


		<script>
        const quotes = [
		    "Write something today that your future self will thank you for.",
		    "Your words have power—use them to inspire the world!",
		    "Every great post starts with a single idea. Start writing!",
		    "Blogging is the voice of today—share your thoughts!",
		    "Your story matters—let the world hear it!",
		    "Creativity knows no limits—let your words flow.",
		    "A single post can change perspectives—write wisely.",
		    "Don’t just consume content—create it!",
		    "Your blog is your digital legacy—make it meaningful.",
		    "Words have the power to inspire, educate, and transform.",
		    "Write what you love, and others will love what you write.",
		    "Every great writer was once a beginner. Keep going!",
		    "Blogging is not just about words; it’s about connecting.",
		    "Consistency beats perfection—just keep writing!",
		    "Your next post could be the one that changes lives.",
		    "Inspire. Inform. Influence. That’s the power of blogging.",
		    "A blog is a conversation. Start one today!",
		    "Your thoughts matter—share them fearlessly.",
		    "A blank page is full of possibilities. Start now!",
		    "Writing is painting with words—create something beautiful.",
		    "Be bold. Be authentic. Be a storyteller.",
		    "Blogging turns thoughts into impact.",
		    "One idea, one post, one moment—make it count!",
		    "Write to express, not just to impress.",
		    "Your words are a reflection of your thoughts. Choose them wisely.",
		    "Every blog post is a step toward greatness.",
		    "Make your blog a place where ideas come alive.",
		    "A single word can spark a revolution. Write yours!",
		    "Your blog is your voice. Let it be heard.",
		    "Great stories begin with a single post.",
		    "Inspiration is everywhere—capture it in your writing.",
		    "Your blog is your online home—make it welcoming.",
		    "The more you write, the better you become.",
		    "Words are the bridges between thoughts and action.",
		    "Don’t fear the blank page—it’s waiting for your magic.",
		    "Writing is the best way to clarify your thoughts.",
		    "Your experiences can inspire someone. Share them!",
		    "Great bloggers aren’t born—they are made through persistence.",
		    "You don’t need to be perfect, just start writing.",
		    "Blogging is your personal stage—own it with confidence.",
		    "Every voice matters, and yours is unique.",
		    "A great post is like a conversation with the reader.",
		    "Success in blogging is about passion and persistence.",
		    "Your perspective is valuable—let the world see it.",
		    "Write not because you have to, but because you love to.",
		    "The best way to improve writing is by writing more.",
		    "Your blog can be the light someone needs today.",
		    "The pen is mightier than the sword—use it wisely.",
		    "When in doubt, write it out!",
		    "Blogging is an art—your words are the brushstrokes.",
		    "A story untold is a story wasted—share yours today!"
		];


        function displayRandomQuote() {
            const quoteElement = document.getElementById("quote");
            const randomIndex = Math.floor(Math.random() * quotes.length);
            quoteElement.textContent = quotes[randomIndex];
        }

        window.onload = displayRandomQuote;
    </script>


		<?php include 'partials/footer.php'; ?>