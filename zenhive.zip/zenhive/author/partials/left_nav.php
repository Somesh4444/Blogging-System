<div class="wrapper">
		<!--sidebar wrapper -->
		<div class="sidebar-wrapper" data-simplebar="true">
			<div class="sidebar-header">
				<div>
					<img src="<?= SITE_URL ?>admin_assets/images/logo-icon.png" class="logo-icon" alt="logo icon" style="width:40px;">
				</div>
				<div>
					<h4 class="logo-text fs-5 text-uppercase">Admin Panel</h4>
				</div>
				<div class="toggle-icon ms-auto"><i class='bx bx-arrow-back'></i>   
				</div>
			 </div>
			<!--navigation-->
			<ul class="metismenu" id="menu">
			<li class="<?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>author/index.php">
					<div class="parent-icon"><i class='bx bx-home-alt'></i></div>
					<div class="menu-title">Dashboard</div>
				</a>
			</li>

				 
			<li class="menu-label">Essentials</li>

			 


			<li class="<?= basename($_SERVER['PHP_SELF']) == 'blogs.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>author/blogs.php">
					<div class="parent-icon"><i class='bx bx-news'></i>
					</div>
					<div class="menu-title">Blog Lists</div>
				</a>
			</li>

			 

			

			<li class="menu-label">Settings</li>

			 

			<li class="<?= basename($_SERVER['PHP_SELF']) == 'changepass.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>author/changepass.php">
					<div class="parent-icon"><i class='bx bx-key'></i>
					</div>
					<div class="menu-title">Change Password</div>
				</a>
			</li>

			<li class="<?= basename($_SERVER['PHP_SELF']) == 'logout.php' ? 'mm-active' : '' ?>">
				<a href="<?= SITE_URL ?>author/logout.php">
					<div class="parent-icon"><i class='bx bx-log-out'></i>
					</div>
					<div class="menu-title">Logout</div>
				</a>
			</li>
				
				 
				 
				 
				 
				 
				 
				 
				 
				 
				 
			</ul>
			<!--end navigation-->
		</div>
		<!--end sidebar wrapper -->
		<!--start header -->