<!--start overlay-->
<div class="overlay toggle-icon"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<footer class="page-footer">
			<p class="mb-0">Copyright © <?= date('Y') ?>. All right reserved. By <a target="_blank" href="https://github.com/Somesh4444">Lipuun</a>.</p>
		</footer>
	</div>
	<!--end wrapper-->

	 

	<!-- Bootstrap JS -->
	<script src="<?= SITE_URL ?>admin_assets/js/bootstrap.bundle.min.js"></script>
	<!--plugins-->
	<script src="<?= SITE_URL ?>admin_assets/js/jquery.min.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<?= SITE_URL ?>admin_assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/plugins/chartjs/js/chart.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
	<!--notification js -->
	<script src="<?= SITE_URL ?>admin_assets/plugins/notifications/js/lobibox.min.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/plugins/notifications/js/notifications.min.js"></script>
	<script src="<?= SITE_URL ?>admin_assets/js/index3.js"></script>
	<!--app JS-->
	<script src="<?= SITE_URL ?>admin_assets/js/app.js"></script>
	 
	 
	<!-- //ckeditor -->
	<script>
        ClassicEditor
            .create(document.querySelector('#editor'))
            .catch(error => {
                console.error(error);
            });
    </script>

<script>
document.getElementById('image-upload').addEventListener('change', function(event) {
    let file = event.target.files[0]; 
    let preview = document.getElementById('image-preview');

    if (file) {
        let reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = `<img src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 5px;">`;
        };
        reader.readAsDataURL(file);
    } else {
        preview.innerHTML = '<p style="color: #888;">No image selected</p>';
    }
});
</script>

<!-- generaate slug from title -->

<script>
function generateSlug() {
    let heading = document.getElementById("heading").value.trim();

    if (heading === "") {
        document.getElementById("urlslug").value = "";
        return;
    }

    let slug = heading
        .toLowerCase() // Convert to lowercase
        .replace(/\s+/g, "-") // Replace spaces with dashes
        .replace(/[^a-z0-9-]/g, "") // Remove special characters except dashes
        .replace(/-+/g, "-"); // Remove multiple dashes

    document.getElementById("urlslug").value = slug;
}
</script>



</body>

</html>