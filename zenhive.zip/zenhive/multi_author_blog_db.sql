-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2025 at 06:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multi_author_blog_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `typ` enum('Admin','User') NOT NULL DEFAULT 'Admin',
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `typ`, `fname`, `lname`, `email`, `password`, `status`) VALUES
(1, 'Admin', 'Admin', 'Lipuu', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', 1);

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `mname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `thumb` varchar(255) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(550) DEFAULT NULL,
  `phone` varchar(12) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `fname`, `mname`, `lname`, `thumb`, `email`, `password`, `phone`, `created_on`, `created_by`, `status`) VALUES
(1, 'Admin', '', '', 'uploads/thumb/1740326141_165546103.jpg', 'admin@gmail.com', 'e22591bbe1941fcc4b78972d4c60281f', '91343453252', '2025-02-19 10:44:19', 1, 1),
(16, 'Santanu', '', 'Das', 'uploads/thumb/1740315906_1739958344_person-5 (1).jpg', 'santanu@gmail.com', 'e22591bbe1941fcc4b78972d4c60281f', '91343453252', '2025-02-19 10:44:19', 1, 1),
(17, 'Ashalata', '', 'Roul', 'uploads/thumb/1739958344_person-5.jpg', 'asha@gmail.com', 'e22591bbe1941fcc4b78972d4c60281f', '1234567898', '2025-02-19 10:45:44', 1, 1),
(18, 'Rajani', 'Kanta', 'Ghadei', 'uploads/thumb/1740573080_1740505920_IMG_20250225_232135.jpg', 'rkg@gmail.com', 'e22591bbe1941fcc4b78972d4c60281f', '1234567899', '2025-02-19 10:46:42', 1, 1),
(19, 'Jyoti', 'Prakash', 'Mandal', 'uploads/thumb/1740316710_file.jpg', 'jyoti@gmail.com', 'e22591bbe1941fcc4b78972d4c60281f', '9999999999', '2025-02-23 14:18:30', 1, 1),
(21, 'Bhola', 'Sankar', 'Nayak', '', 'bhola@gmail.com', '1a1dc91c907325c69271ddf0c944bc72', '9999999999', '2025-02-23 14:18:30', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `heading` varchar(255) DEFAULT NULL,
  `urlslug` varchar(255) DEFAULT NULL,
  `thumb` varchar(250) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `insert_date` date DEFAULT NULL,
  `is_trending` int(1) NOT NULL DEFAULT 0,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(250) NOT NULL DEFAULT 'Admin',
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `author_id`, `cat_id`, `heading`, `urlslug`, `thumb`, `description`, `insert_date`, `is_trending`, `created_on`, `created_by`, `status`) VALUES
(31, 16, 1, 'The Future of Digital Business: Trends to Watch in 2025', 'the-future-of-digital-business-trends-to-watch-in-2025', 'uploads/thumb/1740020663_bb1.png', '<p>As we step into 2025, businesses must stay ahead of emerging trends to remain competitive in an ever-evolving digital landscape. From artificial intelligence to customer-centric strategies, here are the key trends shaping the future of digital business.</p><h4>1. AI and Automation Take Center Stage</h4><p>Artificial Intelligence (AI) and automation are no longer just buzzwords. In 2025, businesses will leverage AI-driven chatbots, predictive analytics, and machine learning models to enhance customer experiences and streamline operations. Automation will help companies cut costs, improve efficiency, and make data-driven decisions faster than ever before.</p><h4>2. The Rise of Personalization</h4><p>Consumers demand personalized experiences, and businesses that deliver them will thrive. AI-powered recommendations, dynamic pricing strategies, and hyper-personalized content marketing will define the way brands interact with their customers. Companies that invest in understanding their audience’s needs will gain a competitive advantage.</p><h4>3. E-commerce Evolution and Social Commerce</h4><p>Online shopping continues to grow, but the way consumers buy products is shifting. Social commerce, where users purchase products directly from social media platforms, is set to boom. With platforms like Instagram, TikTok, and Facebook integrating shopping features, businesses must optimize their social media presence for sales.</p><h4>4. The Dominance of Remote Work and Hybrid Models</h4><p>The global workforce has embraced remote and hybrid work models. Businesses that offer flexibility and invest in collaboration tools will attract top talent. Cloud-based solutions, virtual workspaces, and AI-powered workflow automation will continue to play a crucial role in making remote work more efficient.</p><h4>5. Sustainability and Ethical Business Practices</h4><p>Consumers are becoming more conscious of sustainability and ethical business practices. Companies that adopt eco-friendly initiatives, reduce carbon footprints, and promote ethical sourcing will build stronger brand loyalty. Transparency in operations and corporate social responsibility (CSR) will be key differentiators in 2025.</p><h4>6. The Growing Influence of Blockchain Technology</h4><p>Blockchain is revolutionizing industries beyond cryptocurrency. Businesses are adopting blockchain for secure transactions, supply chain transparency, and decentralized finance (DeFi) solutions. As trust and security become top priorities, blockchain technology will gain mainstream adoption.</p><h4>Final Thoughts</h4><p>The digital business landscape is evolving at an unprecedented pace. Companies that embrace AI, personalization, sustainability, and emerging technologies will lead the way in 2025. Staying ahead of these trends will not only ensure growth but also create meaningful connections with consumers in an increasingly competitive market.</p><p><strong>Are you ready for the future of digital business?</strong> Share your thoughts in the comments below!</p>', '2025-02-20', 1, '2025-02-20 08:34:23', '16', 1),
(32, 16, 2, 'The Importance of Culture in Business Success', 'the-importance-of-culture-in-business-success', 'uploads/thumb/1740021188_dd.png', '<p>Culture plays a vital role in shaping businesses and influencing their success. It defines the values, behaviors, and expectations that drive a company\'s work environment and overall identity. Whether it\'s corporate culture or national traditions, the impact of culture is profound.</p><h4>Understanding Business Culture</h4><p>Business culture is the set of shared values, beliefs, and practices within an organization. It dictates how employees interact, make decisions, and contribute to company goals. A strong business culture fosters collaboration, innovation, and a positive work environment.</p><h4>The Role of Cultural Diversity</h4><p>Cultural diversity in the workplace brings a wealth of benefits, including increased creativity, better problem-solving, and a more inclusive environment. Companies that embrace diverse cultural perspectives tend to be more adaptable and competitive in the global market.</p><h4>Cultural Trends Shaping Businesses in 2025</h4><ol><li><strong>Remote Work Culture</strong> – More companies are adapting to hybrid and remote work environments, emphasizing flexibility and digital collaboration.</li><li><strong>Sustainability and Ethics</strong> – Consumers and employees are prioritizing ethical business practices and sustainability efforts.</li><li><strong>Cross-Cultural Communication</strong> – As businesses expand globally, cultural awareness and effective communication skills are essential.</li><li><strong>Employee Well-Being</strong> – Companies are focusing more on mental health, work-life balance, and creating a supportive work culture.</li></ol><h4>Conclusion</h4><p>Culture is an integral part of business success. Organizations that recognize the power of culture and actively shape it to align with their vision and values will thrive in a dynamic business landscape. By embracing diversity, ethics, and innovation, businesses can create a thriving and inclusive environment for employees and customers alike.</p><p> </p>', '2025-02-20', 0, '2025-02-20 08:43:08', '16', 1),
(33, 17, 3, 'The Joy of Food: A Culinary Journey Across Cultures', 'the-joy-of-food-a-culinary-journey-across-cultures', 'uploads/thumb/1740021830_eraSERG.jpg', '<p>Food is more than just sustenance; it is a gateway to culture, history, and tradition. Across the globe, every dish tells a story, whether it’s about family heritage, local ingredients, or centuries-old cooking techniques. From the spicy curries of India to the comforting pastas of Italy, food serves as a universal language that unites people despite their differences.</p><h4>The Role of Food in Culture</h4><p>Every region has its own unique culinary identity shaped by geography, climate, and history. In Asian countries, rice is a staple, while in Europe, bread and cheese dominate the dining table. Traditional dishes carry the essence of generations, preserving flavors that have been passed down over centuries. Festivals and celebrations around the world, such as Thanksgiving in the United States or Diwali feasts in India, highlight the deep connection between food and communal gatherings.</p><h4>The Rise of Global Cuisine</h4><p>With the rise of globalization, food cultures have merged, leading to exciting fusion cuisines. Sushi burritos, kimchi tacos, and butter chicken pizzas are just a few examples of how different culinary traditions blend to create new gastronomic experiences. This evolution not only broadens our palates but also fosters appreciation for diverse cultures through food.</p><h4>The Art of Cooking and Eating Mindfully</h4><p>Cooking is an art form that engages all senses. The aroma of freshly baked bread, the vibrant colors of a salad, and the sizzle of a stir-fry create an immersive experience. Eating mindfully, savoring each bite, and understanding where our food comes from can enhance our appreciation for the nourishment it provides.</p><h4>Conclusion</h4><p>Food is more than just a necessity; it is an expression of culture, history, and creativity. Whether you’re exploring a new cuisine, trying a family recipe, or dining at a street market, every meal offers a chance to experience the world through taste. So, embrace the joy of food and let every bite be a journey into tradition and innovation.</p>', '2025-02-20', 1, '2025-02-20 08:53:50', '17', 1),
(34, 17, 4, 'The Power of Sports: A Unifying Force', 'the-power-of-sports-a-unifying-force', 'uploads/thumb/1740022037_ewgyet5h.jpg', '<p>Sports have always been an integral part of human civilization, serving as a means of entertainment, competition, and personal growth. From ancient Olympic games to modern global tournaments, sports have continuously evolved, influencing societies and cultures worldwide.</p><h4>The Global Influence of Sports</h4><p>Sports transcend national boundaries, bringing people together regardless of their background. Events like the FIFA World Cup, the Olympics, and the Super Bowl captivate millions, fostering a sense of unity and pride. These competitions showcase the talent and dedication of athletes while also promoting international camaraderie.</p><h4>Health and Fitness Benefits</h4><p>Engaging in sports is one of the most effective ways to maintain physical and mental well-being. Regular participation helps improve cardiovascular health, enhance muscle strength, and boost endurance. Additionally, sports activities release endorphins, reducing stress and anxiety, leading to a healthier lifestyle.</p><h4>Building Character and Discipline</h4><p>Sports teach valuable life skills such as teamwork, leadership, discipline, and perseverance. Whether played professionally or recreationally, they instill a sense of responsibility and determination, preparing individuals for various life challenges.</p><h4>Technological Advancements in Sports</h4><p>With technological advancements, sports have seen significant improvements in training methods, injury prevention, and performance analytics. Wearable fitness trackers, AI-driven coaching tools, and VAR (Video Assistant Referee) technology are just a few examples of innovations shaping the future of sports.</p><h4>The Future of Sports</h4><p>As sports continue to evolve, inclusivity and diversity are becoming key focal points. E-sports, adaptive sports for disabled athletes, and virtual reality training are gaining popularity, offering new opportunities for enthusiasts worldwide.</p><p>Sports will always be more than just games; they are a reflection of society’s values, aspirations, and the relentless pursuit of excellence. Whether you’re an athlete, a fan, or a casual participant, sports have a unique way of inspiring and connecting us all.</p>', '2025-02-20', 0, '2025-02-20 08:57:17', '17', 1),
(35, 18, 5, 'The Ever-Evolving World of Technology', 'the-ever-evolving-world-of-technology', 'uploads/thumb/1740022265_EWQFwgf.jpg', '<p>Technology has become an inseparable part of our daily lives, shaping the way we work, communicate, and interact with the world. From the rise of artificial intelligence to the expansion of the Internet of Things (IoT), the tech industry is constantly innovating, pushing boundaries, and revolutionizing multiple sectors.</p><h4>The Rise of Artificial Intelligence</h4><p>Artificial Intelligence (AI) has transformed industries such as healthcare, finance, and entertainment. AI-powered chatbots enhance customer service, while machine learning algorithms assist in diagnosing diseases with remarkable accuracy. AI-driven automation is also optimizing business operations, reducing human intervention, and improving efficiency.</p><h4>The Internet of Things (IoT) Revolution</h4><p>IoT has connected billions of devices worldwide, allowing seamless communication between smart gadgets. From smart homes with voice-controlled assistants to wearable health monitors tracking vital statistics in real-time, IoT continues to redefine convenience and efficiency.</p><h4>The Impact of 5G and Connectivity</h4><p>The rollout of 5G networks is accelerating internet speeds, reducing latency, and enabling new possibilities such as enhanced virtual and augmented reality experiences. Businesses and consumers alike will benefit from faster connectivity, transforming remote work, gaming, and telemedicine.</p><h4>Cybersecurity in a Digital World</h4><p>As technology advances, so do cyber threats. Cybersecurity has become a crucial aspect of the tech industry, with organizations investing heavily in securing sensitive data and protecting against cyberattacks. With the rise of blockchain technology, decentralized security measures are providing new layers of protection.</p><h4>The Future of Technology</h4><p>From quantum computing to space exploration, the future of technology is limitless. Companies like SpaceX and Blue Origin are pioneering commercial space travel, while advancements in renewable energy tech are paving the way for a sustainable future.</p><p>Technology continues to evolve at an unprecedented pace, reshaping industries and impacting lives. Staying updated on these trends is crucial as we navigate the digital age and embrace the endless possibilities of innovation.</p>', '2025-02-20', 1, '2025-02-20 09:01:05', '18', 1),
(36, 18, 6, 'The Ultimate Guide to Travel: Exploring the World', 'the-ultimate-guide-to-travel-exploring-the-world', 'uploads/thumb/1740022404_vrgyhs.jpg', '<p>Travel is one of the most enriching experiences a person can have. It allows you to explore new cultures, meet people from different backgrounds, and create unforgettable memories. Whether you\'re an adventure seeker, a history buff, or someone who simply loves to relax on a beach, there\'s a destination for you.</p><h4>Why Travel?</h4><p>Traveling opens your mind to new perspectives. It helps you step out of your comfort zone and experience the beauty and diversity of the world. From trying new cuisines to understanding local traditions, every trip offers a unique learning experience.</p><h4>Top Travel Destinations</h4><ol><li><strong>Paris, France</strong> – The city of love, known for its stunning architecture, rich history, and delicious pastries.</li><li><strong>Kyoto, Japan</strong> – A blend of traditional and modern culture, famous for its temples and cherry blossoms.</li><li><strong>Machu Picchu, Peru</strong> – An ancient Incan city nestled in the Andes mountains, offering breathtaking views.</li><li><strong>Santorini, Greece</strong> – A picturesque island with whitewashed buildings and stunning sunsets.</li><li><strong>Bali, Indonesia</strong> – A tropical paradise known for its beautiful beaches, vibrant nightlife, and spiritual retreats.</li></ol><h4>Travel Tips</h4><ul><li><strong>Plan Ahead:</strong> Research your destination to know about local customs, best travel times, and must-visit spots.</li><li><strong>Pack Smart:</strong> Carry essentials, and avoid overpacking to make your journey hassle-free.</li><li><strong>Stay Safe:</strong> Keep emergency contacts handy, and be mindful of your belongings.</li><li><strong>Immerse Yourself:</strong> Engage with locals, try local food, and embrace new experiences with an open heart.</li></ul><h4>Conclusion</h4><p>Traveling is more than just visiting places; it’s about the journey, the experiences, and the stories you bring back. Whether you\'re backpacking through Europe, enjoying a luxurious vacation, or embarking on a solo adventure, travel enriches your life in countless ways.</p><p>Start planning your next trip today and explore the wonders the world has to offer!</p>', '2025-02-20', 0, '2025-02-20 09:03:24', '18', 1),
(37, 17, 9, 'Indian Politics: A Complex and Evolving Landscape', 'indian-politics-a-complex-and-evolving-landscape', 'uploads/thumb/1740110081_post-landscape-3 (1).jpg', '<p>Indian politics is a dynamic and ever-evolving system that influences the lives of over 1.4 billion people. As the world’s largest democracy, India boasts a vibrant political culture shaped by history, diversity, and constitutional principles. From the freedom struggle to modern-day elections, Indian politics has undergone significant transformations, making it an intriguing subject to explore.</p><h4><strong>A Glimpse into India’s Political System</strong></h4><p>India follows a <strong>parliamentary democratic system</strong>, where power is divided among the <strong>executive, legislature, and judiciary</strong>. The President is the constitutional head of state, while the Prime Minister leads the government. The <strong>Lok Sabha (House of the People)</strong> and <strong>Rajya Sabha (Council of States)</strong> form the backbone of India\'s legislative structure. Political parties, both national and regional, play a crucial role in shaping policies and governance.</p><h4><strong>The Role of Political Parties</strong></h4><p>Political parties in India are broadly divided into two categories:</p><ol><li><strong>National Parties</strong> – These include the Bharatiya Janata Party (BJP), Indian National Congress (INC), Aam Aadmi Party (AAP), and others that have a national presence.</li><li><strong>Regional Parties</strong> – These parties cater to specific states or communities, such as the Trinamool Congress (TMC) in West Bengal and the Dravida Munnetra Kazhagam (DMK) in Tamil Nadu.</li></ol><p>With multiple parties contesting elections, coalition politics has become a defining feature of Indian governance.</p><h4><strong>Major Challenges in Indian Politics</strong></h4><p>Despite being a strong democracy, Indian politics faces several challenges:</p><ul><li><strong>Corruption</strong> – Political scandals and misuse of power remain pressing issues.</li><li><strong>Communalism and Caste Politics</strong> – Religion and caste often influence electoral decisions.</li><li><strong>Political Instability</strong> – Frequent shifts in alliances can impact governance.</li><li><strong>Dynastic Politics</strong> – Many political families have maintained control over leadership roles.</li><li><strong>Voter Awareness</strong> – Despite increasing literacy rates, misinformation and lack of political awareness still exist.</li></ul><h4><strong>The Influence of Youth in Politics</strong></h4><p>The youth of India are becoming more politically aware and engaged. With social media platforms acting as a powerful tool, young voters and activists are influencing policies and elections. The rise of independent candidates, student activism, and digital campaigns are shaping the future of Indian democracy.</p><h4><strong>Conclusion</strong></h4><p>Indian politics is a fascinating blend of tradition and modernity. While challenges persist, the resilience of democracy ensures continuous progress. As citizens, participation in voting and governance is crucial to strengthening the political system and shaping a better future for India.</p>', '2025-02-21', 1, '2025-02-21 09:24:41', '17', 1),
(38, 17, 2, 'Exploring the Rich Cultural Heritage of Odisha', 'exploring-the-rich-cultural-heritage-of-odisha', 'uploads/thumb/1740243264_post-landscape-3 (1).jpg', '<p>Odisha, the land of temples, art, and vibrant traditions, is a state deeply rooted in history and culture. Situated on the eastern coast of India, Odisha has preserved its centuries-old heritage, which reflects in its festivals, dance forms, art, cuisine, and architectural marvels. Let’s take a journey through the fascinating cultural landscape of Odisha.</p><h4>Festivals: A Celebration of Tradition</h4><p>Odisha is known for its grand festivals that showcase the state\'s religious and cultural fervor. The world-famous <strong>Rath Yatra</strong> of Puri, dedicated to Lord Jagannath, attracts millions of devotees from around the world. Other notable festivals include <strong>Durga Puja</strong>, <strong>Raja Parba</strong> (a festival celebrating womanhood and agriculture), <strong>Chhau Festival</strong>, and <strong>Makara Sankranti</strong>. Each festival is accompanied by music, dance, and grand feasts that make Odisha a lively and colorful place.</p><h4>Dance and Music: Rhythms of Odisha</h4><p>The classical dance form of <strong>Odissi</strong> is one of the oldest dance traditions in India, characterized by graceful movements and intricate expressions. Odisha is also home to the vibrant <strong>Chhau Dance</strong>, which blends martial arts, folk traditions, and storytelling. The soulful folk music of Odisha, including <strong>Daskathia</strong>, <strong>Pala</strong>, and <strong>Jhumar</strong>, adds to the cultural charm of the state.</p><h4>Art and Handicrafts: A Legacy of Excellence</h4><p>Odisha boasts a rich tradition of handicrafts and art forms. The <strong>Pattachitra paintings</strong>, intricate palm leaf engravings, and stone carvings from the temples of Bhubaneswar, Konark, and Puri are a testament to the state\'s artistic excellence. The silver filigree work of Cuttack, applique work of Pipili, and terracotta crafts are world-renowned for their craftsmanship.</p><h4>Cuisine: A Gastronomic Delight</h4><p>Odisha’s cuisine is simple yet flavorful, with rice being a staple. The famous <strong>Dalma</strong> (lentils cooked with vegetables), <strong>Pakhala Bhata</strong> (fermented rice dish), and the delicious <strong>Chhena Poda</strong> (a baked cottage cheese dessert) are local favorites. The Mahaprasad from the Jagannath Temple in Puri, prepared in a traditional way, is a divine culinary experience for devotees.</p><h4>Architectural Marvels: Temples and Monuments</h4><p>Odisha is a treasure trove of architectural wonders. The <strong>Konark Sun Temple</strong>, a UNESCO World Heritage site, stands as an epitome of ancient craftsmanship. The <strong>Jagannath Temple</strong> in Puri, <strong>Lingaraj Temple</strong> in Bhubaneswar, and the Buddhist sites of Ratnagiri and Udayagiri showcase the architectural and spiritual richness of the state.</p><h4>Conclusion</h4><p>Odisha’s cultural heritage is a blend of spirituality, art, and traditions passed down through generations. Whether you explore its festivals, dance forms, cuisine, or architectural wonders, Odisha offers a unique cultural experience that is deeply enriching and unforgettable. This eastern gem of India continues to preserve its traditions while embracing modernity, making it a fascinating destination for culture enthusiasts.</p><p>Have you experienced Odisha’s rich cultural heritage? Share your thoughts in the comments below!</p><p> </p>', '2025-02-22', 0, '2025-02-22 22:24:24', '17', 1),
(39, 16, 6, 'The Joy of Traveling: Exploring the World', 'the-joy-of-traveling-exploring-the-world', 'uploads/thumb/1740305856_globe-trotter-1828079_960_720.jpg', '<p>Traveling is one of the most exciting and enriching experiences in life. It allows us to explore new places, meet different people, and learn about diverse cultures. Whether it\'s a short trip to a nearby city or a long journey to a foreign land, every travel experience leaves us with unforgettable memories.</p><h4>Why Travel?</h4><p>Traveling is not just about visiting famous tourist spots; it is about discovering the beauty of the world. It helps us break free from our daily routines and brings a fresh perspective to life. Traveling teaches us patience, adaptability, and appreciation for different ways of living.</p><h4>Types of Travel</h4><ol><li><strong>Adventure Travel</strong> – Activities like trekking, river rafting, and wildlife safaris bring thrill and excitement.</li><li><strong>Cultural Travel</strong> – Visiting historical sites, museums, and local festivals helps us understand traditions.</li><li><strong>Nature Travel</strong> – Exploring beaches, mountains, forests, and waterfalls provides peace and relaxation.</li></ol><h4>Tips for a Great Travel Experience</h4><ul><li>Plan your trip well but stay open to surprises.</li><li>Respect the local culture and environment.</li><li>Try local food and interact with the people.</li><li>Capture moments but also live in the present.</li></ul><p>Traveling opens our minds and hearts. It gives us stories to tell and lessons to remember. So pack your bags and start exploring!</p><p> </p><p> </p>', '2025-02-23', 1, '2025-02-23 15:41:27', '16', 1),
(40, 16, 5, 'Rise of Technology in India: A Digital Revolution', 'rise-of-technology-in-india-a-digital-revolution', 'uploads/thumb/1740306141_laptop-5673901_640.jpg', '<p>India has witnessed a massive technological transformation over the past few decades. From being an emerging market to becoming a global technology hub, the country has made significant advancements in various fields like IT, artificial intelligence, digital payments, and space exploration. Technology is not only shaping businesses but also improving the lives of millions of people across the country.</p><h4>India’s Digital Transformation</h4><p>The Indian government’s \"Digital India\" initiative has played a major role in boosting the country’s tech ecosystem. With affordable smartphones and the world’s cheapest internet data rates, India has seen a digital revolution. Today, people can access banking, education, and healthcare services online, making life more convenient.</p><h4>Key Technological Advancements in India</h4><ol><li><strong>IT and Software Industry</strong> – India is home to major IT giants like Infosys, TCS, and Wipro, contributing to global software development.</li><li><strong>Digital Payments</strong> – With the rise of UPI (Unified Payments Interface), India has become one of the leading countries in digital transactions.</li><li><strong>AI and Automation</strong> – Startups and tech companies are using artificial intelligence to enhance industries like healthcare, agriculture, and finance.</li><li><strong>Space Technology</strong> – ISRO’s missions, like Chandrayaan and Mangalyaan, have put India on the global space exploration map.</li></ol><h4>The Future of Technology in India</h4><p>India is rapidly adopting 5G, blockchain, and smart city technologies. With a growing startup ecosystem and government support, the country is on its way to becoming a global tech powerhouse.</p><p>Technology is not just changing industries; it is transforming lives. As India continues to innovate, the future looks bright for a digital and tech-driven nation!</p><p> </p><p> </p>', '2025-02-23', 0, '2025-02-23 15:52:21', '16', 1),
(41, 18, 9, 'Importance of Voting in America: A Voice for Change', 'importance-of-voting-in-america-a-voice-for-change', 'uploads/thumb/1740306333_vote-9176783_640.jpg', '<p>Voting is one of the most fundamental rights and responsibilities of American citizens. It is the foundation of democracy, allowing people to choose their leaders and shape the future of the country. Every vote matters, and history has shown that elections can be decided by just a small margin.</p><h4>Why Is Voting Important?</h4><p>Voting gives people a voice in decisions that affect their lives. From healthcare and education to jobs and taxes, elected leaders make policies that impact everyone. By voting, citizens can support candidates and policies that align with their values and beliefs.</p><h4>How Voting Works in America</h4><ol><li><strong>Voter Registration</strong> – Citizens must register before they can vote. Each state has its own registration process and deadlines.</li><li><strong>Election Types</strong> – There are local, state, and federal elections, including the presidential election every four years.</li><li><strong>Voting Methods</strong> – Americans can vote in person, by mail, or through early voting options, depending on state laws.</li></ol><h4>Challenges and Voter Participation</h4><p>Despite the importance of voting, voter turnout in the U.S. varies. Some people do not vote due to lack of awareness, long wait times, or restrictive voting laws. However, efforts like online registration and voter education campaigns are helping increase participation.</p><h4>Every Vote Counts</h4><p>Elections shape policies and laws that affect generations. Whether in a small town or a big city, each vote contributes to the direction of the country. Participating in elections is not just a right—it is a duty that strengthens democracy.</p><p>By voting, Americans take part in building a better future for themselves and their communities. So, when election time comes, make sure your voice is heard—every vote makes a difference!</p><p> </p><p> </p>', '2025-02-23', 0, '2025-02-23 15:55:33', '18', 1),
(42, 18, 4, 'The Olympics: A Celebration of Sports and Unity', 'the-olympics-a-celebration-of-sports-and-unity', 'uploads/thumb/1740306553_post-landscape-3 (4).jpg', '<p>The Olympics is the world’s biggest and most prestigious sporting event, bringing together athletes from different countries to compete at the highest level. Held every four years, the Games symbolize unity, excellence, and the spirit of sportsmanship.</p><h4>The History of the Olympics</h4><p>The Olympic Games date back to ancient Greece, where they were first held in 776 BC. The modern Olympics began in 1896, thanks to the efforts of Pierre de Coubertin, who believed in using sports to promote peace and friendship among nations. Since then, the Games have grown, with more sports, athletes, and countries participating.</p><h4>The Spirit of the Olympics</h4><p>The Olympics are more than just sports competitions. They represent:</p><ol><li><strong>Unity</strong> – Athletes from all over the world compete, showing that sports can bring people together despite differences.</li><li><strong>Determination</strong> – Athletes train for years to achieve their dreams of winning medals.</li><li><strong>Fair Play</strong> – The Games emphasize respect, teamwork, and honesty in sports.</li></ol><h4>India at the Olympics</h4><p>India has made great progress in the Olympics, winning medals in hockey, wrestling, badminton, and athletics. Athletes like Neeraj Chopra, P.V. Sindhu, and Abhinav Bindra have brought pride to the nation.</p><h4>The Future of the Olympics</h4><p>With advancements in technology, the Olympics are becoming more exciting and inclusive. New sports are added, and sustainability is now a focus in hosting the Games.</p><p>The Olympics inspire millions, proving that hard work and dedication can lead to greatness. As the world comes together every four years, the Games remind us of the power of sports in promoting peace and friendship.</p><p> </p><p> </p>', '2025-02-23', 0, '2025-02-23 15:57:58', '18', 1),
(43, 18, 3, 'A Taste of Odisha: Exploring Its Delicious Cuisine', 'a-taste-of-odisha-exploring-its-delicious-cuisine', 'uploads/thumb/1740307158_post-landscape-3 (5).jpg', '<p>Odisha, a beautiful state on the eastern coast of India, is known not only for its rich culture and heritage but also for its mouthwatering food. Odia cuisine is simple yet flavorful, with a perfect balance of spices and natural ingredients. The use of rice, lentils, vegetables, and seafood makes Odia food both nutritious and delicious.</p><h4>Famous Dishes of Odisha</h4><ol><li><strong>Dalma</strong> – A wholesome dish made with lentils, vegetables, and mild spices, Dalma is a staple in Odia households and is also served as part of the famous Jagannath Temple Mahaprasad.</li><li><strong>Pakhala Bhata</strong> – This fermented rice dish, soaked in water and often eaten with curd, vegetables, and fried fish, is Odisha’s favorite summer food, keeping the body cool and refreshed.</li><li><strong>Chhena Poda</strong> – Known as Odisha’s signature dessert, Chhena Poda is a delicious baked cottage cheese sweet with a caramelized flavor, loved by people of all ages.</li><li><strong>Rasagola</strong> – Odisha is the birthplace of the famous Rasagola, a soft and spongy sweet made of chhena (cottage cheese) and soaked in sugar syrup. It has a special place in Odia festivals and traditions.</li><li><strong>Santula</strong> – A simple yet healthy dish made with boiled vegetables and light spices, Santula is easy to digest and packed with nutrients.</li><li><strong>Macha Besara</strong> – Fish cooked in mustard gravy is a popular dish in coastal Odisha, known for its tangy and spicy flavors.</li></ol><h4>Food and Festivals</h4><p>Food plays an important role in Odia festivals. During Raja festival, special dishes like Poda Pitha are prepared, while Chhapan Bhog (56 different dishes) is offered to Lord Jagannath in Puri. The variety of temple foods in Odisha, especially the Mahaprasad of Jagannath Temple, is world-famous.</p><h4>Conclusion</h4><p>Odisha’s food is a perfect blend of tradition, taste, and health. Whether you are a fan of spicy curries or sweet delights, Odia cuisine has something for everyone. If you ever visit Odisha, don’t miss the chance to taste its unique and delicious dishes!</p><p> </p><p> </p>', '2025-02-23', 0, '2025-02-23 16:09:18', '18', 1),
(44, 17, 1, 'Art of Business: Building Success with Smart Strategies', 'art-of-business-building-success-with-smart-strategies', 'uploads/thumb/1740307484_teamwork-3213924_640.jpg', '<p>Business is the backbone of any economy, driving innovation, creating jobs, and contributing to a country’s growth. Whether it’s a small startup or a large corporation, every business requires careful planning, dedication, and the right strategies to succeed.</p><h4>Why Start a Business?</h4><p>Starting a business gives individuals the opportunity to follow their passion, be their own boss, and create something valuable for society. Businesses not only generate income but also solve problems, introduce new products, and improve people’s lives.</p><h4>Key Elements of a Successful Business</h4><ol><li><strong>A Clear Vision</strong> – Every business starts with an idea. Having a strong vision and mission helps guide the company toward its goals.</li><li><strong>Market Research</strong> – Understanding customer needs, competitors, and industry trends is crucial for making informed decisions.</li><li><strong>Financial Planning</strong> – Managing money wisely, controlling expenses, and ensuring steady revenue flow are key to sustainability.</li><li><strong>Effective Marketing</strong> – Using digital marketing, social media, and advertisements helps businesses reach more customers.</li><li><strong>Customer Satisfaction</strong> – Happy customers lead to repeat business and positive word-of-mouth, which boosts growth.</li></ol><h4>Business Trends in India</h4><p>India is witnessing a boom in entrepreneurship, with startups emerging in technology, e-commerce, and finance. Government initiatives like \"Make in India\" and \"Startup India\" are encouraging more people to take the business route. Digital transformation, e-commerce, and online services are shaping the future of business in India.</p><h4>Challenges in Business</h4><p>Running a business comes with risks like competition, financial difficulties, and changing market demands. However, with innovation, adaptability, and smart decision-making, businesses can overcome challenges and thrive.</p><h4>Conclusion</h4><p>Business is more than just making money; it’s about solving problems, creating value, and making an impact. With the right mindset and strategies, anyone can turn an idea into a successful venture. Whether small or big, every business has the power to change lives and shape the future!</p><p> </p><p> </p>', '2025-02-23', 0, '2025-02-23 16:14:44', '17', 1),
(45, 16, 6, 'Discovering New Places and Cultures', 'discovering-new-places-and-cultures', 'uploads/thumb/1740312807_post-landscape-3 (2).jpg', '<p>Traveling is more than just visiting new places; it’s about experiencing different cultures, meeting new people, and creating lifelong memories. Whether it’s exploring the mountains, relaxing on a beach, or discovering historic cities, travel brings excitement and learning.</p><h4>Why Travel?</h4><p>Traveling allows us to step out of our comfort zones and see the world from a new perspective. It helps reduce stress, improves creativity, and brings a sense of adventure. Every destination has something unique to offer, from delicious food to breathtaking landscapes.</p><h4>Best Ways to Travel</h4><ul><li><strong>Solo Travel</strong> – A great way to find independence and self-discovery.</li><li><strong>Family Trips</strong> – Strengthens bonds and creates shared memories.</li><li><strong>Road Trips</strong> – Offers flexibility and a chance to explore offbeat destinations.</li><li><strong>Cultural Travel</strong> – Visiting historical places and learning about traditions.</li></ul><h4>Travel Tips for a Great Experience</h4><ul><li>Plan your trip but stay open to surprises.</li><li>Respect local culture and traditions.</li><li>Try local food and interact with locals.</li><li>Travel light and pack smart.</li></ul><h4><strong>Conclusion</strong></h4><p>Traveling is a wonderful way to explore the beauty of the world. Whether it’s a short trip or a long journey, each experience adds value to life. So, pack your bags, embrace the unknown, and let every trip be an adventure!</p><p> </p><p> </p>', '2025-02-23', 1, '2025-02-23 17:43:27', '16', 1),
(46, 16, 1, 'Building a Successful Business', 'building-a-successful-business', 'uploads/thumb/1740312996_office-desk-6952919_640.jpg', '<p>Business is the key to growth, innovation, and financial freedom. Whether it’s a small startup or a large company, success comes from smart planning, dedication, and adaptability.</p><h4>Why Start a Business?</h4><p>Starting a business gives you the freedom to follow your passion, be your own boss, and create value. It also helps generate jobs and boost the economy.</p><h4>Keys to Success</h4><ul><li><strong>Clear Vision</strong> – Define your goals and purpose.</li><li><strong>Market Research</strong> – Understand customer needs and competition.</li><li><strong>Smart Finances</strong> – Manage expenses and revenue wisely.</li><li><strong>Effective Marketing</strong> – Use digital tools to reach more customers.</li><li><strong>Customer Focus</strong> – Happy customers bring business growth.</li></ul><h4>Business in India</h4><p>India’s startup scene is booming, with government support and digital advancements helping new businesses thrive.</p><h4>Final Thoughts</h4><p>A great business starts with a strong idea and the right execution. Stay innovative, take risks, and keep growing!</p><p> </p><p> </p>', '2025-02-23', 0, '2025-02-23 17:46:36', '16', 1),
(48, 1, 5, 'Future Tech: Innovations Transforming Our World', 'future-tech-innovations-transforming-our-world', 'uploads/thumb/1740325890_post-landscape-3 (1).jpg', '<p>Technology is evolving at an unprecedented pace, transforming the way we live, work, and interact. From artificial intelligence to quantum computing, groundbreaking innovations are revolutionizing industries and redefining possibilities.</p><h4>1. Artificial Intelligence &amp; Machine Learning</h4><p>AI is no longer a futuristic concept—it’s here, making life smarter and more efficient. From self-driving cars to personalized recommendations on streaming platforms, AI is improving decision-making, automating tasks, and enhancing user experiences.</p><h4>2. The Rise of 5G and Beyond</h4><p>The introduction of 5G is changing the digital landscape with ultra-fast internet speeds and low latency. This advancement paves the way for smart cities, improved IoT (Internet of Things) devices, and seamless connectivity in remote areas.</p><h4>3. Blockchain and Cybersecurity</h4><p>With cyber threats increasing, blockchain technology is stepping up to ensure secure transactions and data integrity. Beyond cryptocurrency, industries like finance, healthcare, and supply chain management are leveraging blockchain for transparency and security.</p><h4>4. Quantum Computing: The Next Big Leap</h4><p>Quantum computing has the potential to solve complex problems beyond the capabilities of traditional computers. Companies like Google and IBM are investing heavily in this technology, which could revolutionize fields like cryptography, pharmaceuticals, and climate modeling.</p><h4>5. The Future of Work: Automation &amp; Remote Technologies</h4><p>The pandemic accelerated digital transformation, making remote work and automation more relevant than ever. Businesses are adopting AI-driven chatbots, virtual assistants, and robotic process automation to streamline operations and boost productivity.</p><h4>Final Thoughts</h4><p>As technology advances, it brings exciting opportunities and challenges. The key lies in ethical development and responsible innovation to ensure these advancements benefit humanity. The future is digital—are you ready to embrace it? </p><p>What are your thoughts on the future of technology? Let us know in the comments!</p>', '2025-02-23', 1, '2025-02-23 21:21:30', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `urlslug` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `urlslug`, `created_on`, `status`) VALUES
(1, 'Business', 'business', '2025-02-19 00:29:53', 1),
(2, 'Culture', 'culture', '2025-02-19 00:29:53', 1),
(3, 'Food', 'food', '2025-02-19 00:29:53', 1),
(4, 'Sport', 'sport', '2025-02-19 00:29:53', 1),
(5, 'Tech', 'tech', '2025-02-19 00:29:53', 1),
(6, 'Travel', 'travel', '2025-02-19 00:29:53', 1),
(9, 'Politics', 'politics', '2025-02-21 04:42:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `blog_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `blog_id`, `name`, `email`, `message`, `created_at`, `status`) VALUES
(1, 36, 'Mona', 'mona69@gmail.com', 'This is a Nice Blog I like this', '2025-02-21 17:52:39', 1),
(2, 32, 'Remsi Sahoo', 'r@gmail.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', '2025-02-22 04:00:21', 1),
(3, 31, 'SoumyaJit', 'soumya@gmail.com', 'The digital business landscape is evolving at an unprecedented pace. Nice Conclusion...', '2025-02-22 08:07:46', 1),
(5, 38, 'Saroj Mohanty', 'saroj@gmail.com', 'Jay Jagannath.......', '2025-02-22 16:55:27', 1),
(6, 37, 'Mona', 'mona69@gmail.com', 'Are Modi Jii NAMASTE!!!!!', '2025-02-23 05:20:59', 1),
(7, 38, 'Ashu', 'ashu@gmail.com', 'Nice', '2025-02-23 05:30:30', 1),
(8, 39, 'Rupali Maharana', 'rupali@gmail.com', 'I love travelling...........', '2025-02-23 10:32:11', 1),
(9, 43, 'GUDU', 'gudu@gmail.com', 'WOOOWW Looks Delicious......', '2025-02-23 10:40:09', 1),
(10, 38, 'Ravindra', 'ravi@gmail.com', 'Jay Jagannath', '2025-02-23 13:25:18', 1),
(11, 33, 'Anjali Das', 'anjali@gmail.com', 'LOOKS NICE..', '2025-02-26 12:32:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_leads`
--

CREATE TABLE `contact_leads` (
  `id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_leads`
--

INSERT INTO `contact_leads` (`id`, `name`, `email`, `subject`, `message`, `created_on`, `status`) VALUES
(1, 'Saroj Mohanty', 'saroj@gmail.com', 'Testt', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '2025-02-09 22:46:07', 1),
(5, 'Dipu', 'dipu@gmail.com', 'test', 'test', '2025-02-25 19:39:46', 1),
(6, 'ddd', 'mona69@gmail.com', 'zzzrgtrwa', 'zdrg', '2025-02-25 22:01:44', 1),
(7, 'Lipuun', 'admin@gmail.com', 'test', 'test', '2025-02-25 22:02:10', 1),
(8, 'Mona', 'godknows@gmail.com', 'test', 'sssss', '2025-02-25 22:03:08', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_id` (`blog_id`);

--
-- Indexes for table `contact_leads`
--
ALTER TABLE `contact_leads`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contact_leads`
--
ALTER TABLE `contact_leads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
