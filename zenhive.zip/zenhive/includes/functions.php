<?php
// admin/functions.php
include '../includes/db.php';



function dump_data($data) {
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}

/**
 * Insert data into a table
 * @param string $table - Table name
 * @param array $data - Associative array of data to insert
 * @return bool - True on success, False on failure
 */
function insert($table, $data) {
    global $conn;
    $columns = implode(', ', array_keys($data));
    $values = ':' . implode(', :', array_keys($data));
    $sql = "INSERT INTO $table ($columns) VALUES ($values)";
    $stmt = $conn->prepare($sql);
    return $stmt->execute($data);
}

/**
 * Update data in a table
 * @param string $table - Table name
 * @param array $data - Associative array of data to update
 * @param string $condition - SQL condition (e.g., "id = 1")
 * @return bool - True on success, False on failure
 */
function update($table, $data, $condition) {
    global $conn;
    $set = [];
    foreach ($data as $key => $value) {
        $set[] = "$key = :$key";
    }
    $set = implode(', ', $set);
    $sql = "UPDATE $table SET $set WHERE $condition";
    $stmt = $conn->prepare($sql);
    return $stmt->execute($data);
}

/**
 * Delete data from a table
 * @param string $table - Table name
 * @param string $condition - SQL condition (e.g., "id = 1")
 * @return bool - True on success, False on failure
 */
function delete($table, $condition) {
    global $conn;
    $sql = "DELETE FROM $table WHERE $condition";
    $stmt = $conn->prepare($sql);
    return $stmt->execute();
}

/**
 * Fetch data from a table
 * @param string $table - Table name
 * @param string $condition - SQL condition (e.g., "id = 1")
 * @return array - Associative array of fetched data
 */
// function fetch($table, $condition = '1') {
//     global $conn;
//     $sql = "SELECT * FROM $table WHERE $condition";
//     $stmt = $conn->prepare($sql);
//     $stmt->execute();
//     return $stmt->fetchAll(PDO::FETCH_ASSOC);
// }

function fetch($table, $condition = '1', $params = [], $order_by = 'id DESC') {
    global $conn;

    $sql = "SELECT * FROM $table WHERE $condition ORDER BY $order_by";
    $stmt = $conn->prepare($sql);

    // Check if params are provided and execute accordingly
    if (!empty($params)) {
        $stmt->execute($params);
    } else {
        $stmt->execute();
    }

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

  








function sanitize($input) {
    return trim(htmlspecialchars($input, ENT_QUOTES, 'UTF-8'));
}

//image upload
// function uploadImage($file, $folder = 'uploads/thumb/') {
//     if (!empty($file['name'])) {
//         if (!is_dir($folder)) {
//             mkdir($folder, 0777, true); // Create folder if not exists
//         }
//         $file_name = time() . '_' . basename($file["name"]);
//         $file_path = $folder . $file_name;

//         return move_uploaded_file($file["tmp_name"], $file_path) ? $file_name : false;
//     }
//     return false;
// }

function uploadImage($file, $folder = '../uploads/thumb/') { // Go one level up to avoid /admin/
    $upload_dir = realpath($folder) ?: $folder; // Get absolute path or use relative path

    if (!empty($file['name'])) {
        // Ensure the folder exists (create it if not)
        if (!is_dir($upload_dir)) {
            if (!mkdir($upload_dir, 0777, true)) {
                error_log("Failed to create directory: $upload_dir");
                return false;
            }
        }

        $file_name = time() . '_' . basename($file["name"]);
        $file_path = $upload_dir . '/' . $file_name; // Absolute path for moving file

        // Move the uploaded file
        if (move_uploaded_file($file["tmp_name"], $file_path)) {
            return 'uploads/thumb/' . $file_name; // Return correct relative path
        } else {
            error_log("File upload failed: " . print_r(error_get_last(), true));
            return false;
        }
    }
    return false;
}






// alerts 

function showAlert($message, $type = 'primary') {
    $icons = [
        'primary'   => 'bx bx-bookmark-heart',
        'success'   => 'bx bx-check-circle',
        'danger'    => 'bx bx-error',
        'warning'   => 'bx bx-error-circle',
        'info'      => 'bx bx-info-circle',
        'dark'      => 'bx bx-moon'
    ];

    $icon = $icons[$type] ?? 'bx bx-info-circle'; // Default icon if type is not found

    return '
    <div class="custom-alert alert alert-' . $type . ' border-0 bg-' . $type . ' alert-dismissible fade show py-2">
        <div class="d-flex align-items-center">
            <div class="font-35 text-white"><i class="' . $icon . '"></i></div>
            <div class="ms-3">
                <h6 class="mb-0 text-white text-capitalize">' . ucfirst($type) . ' Alert</h6>
                <div class="text-white">' . $message . '</div>
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}






?>