<?php
session_start();
include '../includes/functions.php';

// Get the current script path
$currentPath = $_SERVER['PHP_SELF'];

// Check if the user is logged in as admin
if (isset($_SESSION['admin_id'])) {
    // If an author session exists, destroy it (prevents conflicts)
    if (isset($_SESSION['author_id'])) {
        session_unset();
        session_destroy();
        header('Location: ../admin/login.php');
        exit();
    }

    // Prevent admin from accessing the author panel
    if (strpos($currentPath, '/author/') !== false) {
        header('Location: ../admin/index.php');
        exit();
    }
}

// Check if the user is logged in as author
if (isset($_SESSION['author_id'])) {
    // If an admin session exists, destroy it (prevents conflicts)
    if (isset($_SESSION['admin_id'])) {
        session_unset();
        session_destroy();
        header('Location: ../author/login.php');
        exit();
    }

    // Prevent author from accessing the admin panel
    if (strpos($currentPath, '/admin/') !== false) {
        header('Location: ../author/index.php');
        exit();
    }
}

// If neither admin nor author is logged in, redirect to the correct login page
if (!isset($_SESSION['admin_id']) && !isset($_SESSION['author_id'])) {
    if (strpos($currentPath, '/admin/') !== false) {
        header('Location: ../admin/login.php');
    } else {
        header('Location: ../author/login.php');
    }
    exit(); 
}
?>
