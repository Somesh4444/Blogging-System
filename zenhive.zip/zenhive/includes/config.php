<?php
// Define global constants for company details
define('SITE_URL', 'http://localhost/zenhive/');
define('COMPANY_NAME', 'ZenHive - Multi Author Blogging System');
define('COMPANY_LOGO', 'assets/logo.png');
define('COMPANY_EMAIL', 'ofcsomu@gmail.com');
define('COMPANY_ADDRESS', 'Old Town,Bhubaneswar');
define('COMPANY_PHONE', '+91 1895548855'); 
define('FB', 'https://www.facebook.com/somesh.behera.96'); 
define('GITHUB', 'https://github.com/somesh4444'); 
define('X', 'https://x.com/ofc_lipu'); 



?>
