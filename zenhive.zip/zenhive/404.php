 <?php
  include'layout/header.php';
?>

<style type="text/css">
  #lottie-404 {
    width: 500px;
}

</style>

  <main id="main">
    <section>
      <div class="container" data-aos="fade-up">
        <div class="row d-none">
          <div class="col-lg-12 text-center mb-5">
            <h1 class="page-title">404 ERROR</h1>
          </div>
        </div>

        <div class="d-flex justify-content-center align-items-center mb-5" style="flex-direction: column;">

          <div id="lottie-404"></div>
            
          <a href="<?=SITE_URL?>"><input type="submit" class="btn btn-primary" value="Back To Home"></a>
           

        </div>

      </div>
    </section>

     

  </main><!-- End #main -->

  <?php
  include'layout/footer.php';
?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.9.6/lottie.min.js"></script>
<script>
    lottie.loadAnimation({
        container: document.getElementById('lottie-404'), 
        renderer: 'svg',
        loop: true,
        autoplay: true,
        path: '404.json' // Path to your Lottie JSON file
    });
</script>
