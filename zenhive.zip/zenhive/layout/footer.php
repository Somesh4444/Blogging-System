<!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="footer-content">
      <div class="container">

        <div class="row g-5">
          <div class="col-lg-4">
            <h3 class="footer-heading"><?=COMPANY_NAME?></h3>
            <p>we believe in the power of words to inform, inspire, and connect. Our platform is a space for passionate writers and curious readers to explore diverse topics, from the latest trends in technology to the richness of culture, travel, sports, and beyond.</p>
            <p><a href="about.html" class="footer-link-more">Learn More</a></p>
          </div>
          <div class="col-6 col-lg-2">
            <h3 class="footer-heading">Navigation</h3>
            <ul class="footer-links list-unstyled">
              <li><a href="<?=SITE_URL?>"><i class="bi bi-chevron-right"></i> Home</a></li>
              <li><a href="<?=SITE_URL?>about.php"><i class="bi bi-chevron-right"></i> About us</a></li>
              <li><a href="<?=SITE_URL?>contact.php"><i class="bi bi-chevron-right"></i> Contact</a></li>
              <li><a href="<?=SITE_URL?>author" target="_blank"><i class="bi bi-chevron-right"></i> Author Login</a></li>
              <li><a href="<?=SITE_URL?>contact.php"><i class="bi bi-chevron-right"></i> Become An Author</a></li>
            </ul>
          </div>
          <div class="col-6 col-lg-2">
            <h3 class="footer-heading">Categories</h3>
            <ul class="footer-links list-unstyled">
              <!-- <li><a href="<?=SITE_URL?>blog.php"><i class="bi bi-chevron-right"></i> All</a></li> -->
              <?php
                foreach ($categories as $dpa) {
                  $salt = bin2hex(random_bytes(5)); // Generating a random salt
                  $encoded_id = base64_encode($salt . $dpa['id']);
              ?>
              <li><a href="<?=SITE_URL?>blog.php?category=<?=$encoded_id?>"><i class="bi bi-chevron-right"></i> <?=$dpa['name']?></a></li>
               <?php
                }
              ?>

            </ul>
          </div>

          <div class="col-lg-4">
            <h3 class="footer-heading">Recent Posts</h3>

            <ul class="footer-links footer-blog-entry list-unstyled">
              
              <?php
                foreach ($nn as $k) {
              ?>

              <li>
                <a href="blog-details.php?slug=<?=$k['urlslug']?>" class="d-flex align-items-center">
                  <img src="<?= SITE_URL . $k['thumb'] ?>" alt="" class="img-fluid me-3">
                  <div>
                    <div class="post-meta d-block"><span class="date"><?=$k['category_name']?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($k['insert_date'])) ?></span></div>
                    <span><?=$k['heading']?></span>
                  </div>
                </a>
              </li>

              <?php
                }
              ?>

            </ul>

          </div>
        </div>
      </div>
    </div>

    <div class="footer-legal">
      <div class="container">

        <div class="row justify-content-between">
          <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
            <div class="copyright">
              © Copyright <strong><span>ZenHive</span></strong>. All Rights Reserved
            </div>

            <div class="credits">
              Designed & Developed by <a href="https://github.com/somesh4444">Somesh</a>
            </div>

          </div>

          <div class="col-md-6">
            <div class="social-links mb-3 mb-lg-0 text-center text-md-end">
              <a href="<?=X?>" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="<?=FB?>" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="<?=GITHUB?>" class="google-plus"><i class="bi bi-github"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>

          </div>

        </div>

      </div>
    </div>

  </footer>

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?=SITE_URL?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?=SITE_URL?>assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?=SITE_URL?>assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?=SITE_URL?>assets/vendor/aos/aos.js"></script>
  <script src="<?=SITE_URL?>assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?=SITE_URL?>assets/js/main.js"></script>




  <script type="text/javascript">
    function timeAgo(datetime) {
      let time = new Date(datetime);
      let now = new Date();
      let diffInSeconds = Math.floor((now - time) / 1000);

      let timeUnits = [
          { unit: "year", seconds: 31556926 },
          { unit: "month", seconds: 2629743 },
          { unit: "week", seconds: 604800 },
          { unit: "day", seconds: 86400 },
          { unit: "hour", seconds: 3600 },
          { unit: "minute", seconds: 60 },
          { unit: "second", seconds: 1 }
      ];

      for (let i = 0; i < timeUnits.length; i++) {
          let elapsed = Math.floor(diffInSeconds / timeUnits[i].seconds);
          if (elapsed > 0) {
              return elapsed + " " + timeUnits[i].unit + (elapsed > 1 ? "s" : "") + " ago";
          }
      }
      return "Just now";
  }

  </script>

  <script>
  document.addEventListener("DOMContentLoaded", function () {
      let elements = document.querySelectorAll(".time-ago");
      elements.forEach(function (el) {
          let datetime = el.getAttribute("data-time");
          el.innerText = timeAgo(datetime);
      });
  });
  </script>
















</body>

</html>