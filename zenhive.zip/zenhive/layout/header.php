<?php
    include 'includes/config.php';
    include 'includes/db.php';

    $stmt = $conn->query("SELECT * FROM category");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $conn->query("SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
        (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
        (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
        FROM blogs b WHERE b.status = 1 ORDER BY b.id DESC limit 4");

    $nn = $stmt->fetchAll(PDO::FETCH_ASSOC);


    // echo "<pre>";
    // print_r($categories);
    // echo "</pre>";exit;

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?=COMPANY_NAME?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?=SITE_URL?>assets/img/favicon.png" rel="icon">
  <link href="<?=SITE_URL?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;500&family=Inter:wght@400;500&family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?=SITE_URL?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?=SITE_URL?>assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?=SITE_URL?>assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="<?=SITE_URL?>assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?=SITE_URL?>assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS Files -->
  <link href="<?=SITE_URL?>assets/css/variables.css" rel="stylesheet">
  <link href="<?=SITE_URL?>assets/css/main.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>ZenHive</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="<?=SITE_URL?>index.php">Home</a></li>
          <!-- <li><a href="single-post.html">Single Post</a></li> -->
          <li class="dropdown"><a href="<?=SITE_URL?>404.php"><span>Categories</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <?php
                foreach ($categories as $dpa) {
                  $salt = bin2hex(random_bytes(5)); // Generating a random salt
                  $encoded_id = base64_encode($salt . $dpa['id']);
              ?>
              <li><a href="<?=SITE_URL?>blog.php?category=<?=$encoded_id?>"><?=$dpa['name']?></a></li>
               <?php
                }
              ?>
            </ul>
          </li>

          <li><a href="<?=SITE_URL?>blog.php">Blogs</a></li>
          <li><a href="<?=SITE_URL?>about.php">About</a></li>
          <li><a href="<?=SITE_URL?>contact.php">Contact</a></li>
          <li><a href="<?=SITE_URL?>author" target="_blank">Author's Login</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="<?=FB?>" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="<?=X?>" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="<?=GITHUB?>" class="mx-2"><span class="bi-github"></span></a>

        <a href="#" class="mx-2 js-search-open"><span class="bi-search"></span></a>
        <i class="bi bi-list mobile-nav-toggle"></i>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="blog.php" method="GET" class="search-form">
            <span class="icon bi-search"></span>
            <input type="text" name="q" placeholder="Search blogs..." class="form-control" required>
            
            <!-- Hidden submit button -->
            <button type="submit" style="display: none;"></button>

            <!-- Close button (not a submit button) -->
            <button type="button" class="btn js-search-close"><span class="bi-x"></span></button>
        </form>


        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->

  <script>
    document.querySelector(".search-form input[name='q']").addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            this.closest("form").submit();
        }
    });
    </script> 
