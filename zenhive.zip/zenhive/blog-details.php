<?php
  ob_start();
  include 'layout/header.php';

  $stmt = $conn->query("SELECT * FROM category");
  $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

  if (isset($_GET['slug'])) {
    $slug = $_GET['slug'];

    // Prepare SQL query to fetch blog details
    $stmt = $conn->prepare("SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
        (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
        (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
        FROM blogs b WHERE b.urlslug = :slug AND b.status = 1 LIMIT 1");
    
    $stmt->bindParam(':slug', $slug, PDO::PARAM_STR);
    $stmt->execute();
    $blog = $stmt->fetch(PDO::FETCH_ASSOC);

    // echo"<pre>";
    // print_r($blog);
    // echo"<pre>";exit;

    // If blog not found, redirect to 404
    if (!$blog) {
        header("Location: 404.php");
        exit();
    }
} else {
    header("Location: 404.php");
    exit();
}

$tb = $conn->query("SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
        (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
        (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
        FROM blogs b 
        WHERE b.status = 1 AND b.is_trending = 1
        ORDER BY b.id DESC limit 10");

  $trending_blogs = $tb->fetchAll(PDO::FETCH_ASSOC);

  $ab = $conn->query("SELECT b.*, 
        (SELECT name FROM category WHERE id = b.cat_id) AS category_name,
        (SELECT CONCAT(fname, ' ', lname) FROM authors WHERE id = b.author_id) AS author_name,
        (SELECT thumb FROM authors WHERE id = b.author_id) AS author_thumb
        FROM blogs b 
        WHERE b.status = 1
        ORDER BY b.id DESC limit 10");

  $latest_blogs = $ab->fetchAll(PDO::FETCH_ASSOC);

  session_start(); // Start session for storing success message

  if (isset($_POST['submit_comment'])) {
      $name = trim($_POST['name']);
      $email = trim($_POST['email']);
      $message = trim($_POST['message']);
      $blog_id = $blog['id'];

      if (!empty($name) && !empty($email) && !empty($message)) {
          $stmt = $conn->prepare("INSERT INTO comments (blog_id, name, email, message) VALUES (:blog_id, :name, :email, :message)");
          $stmt->execute([
              ':blog_id' => $blog_id,
              ':name' => $name,
              ':email' => $email,
              ':message' => $message
          ]);

          $_SESSION['comment_success'] = "Your comment has been posted successfully!"; // Store message
      }
  }



  $comments_stmt = $conn->prepare("SELECT * FROM comments WHERE blog_id = :blog_id ORDER BY created_at DESC");
  $comments_stmt->bindParam(':blog_id', $blog['id'], PDO::PARAM_INT);
  $comments_stmt->execute();
  $comments = $comments_stmt->fetchAll(PDO::FETCH_ASSOC);

  $comment_count_stmt = $conn->prepare("SELECT COUNT(*) AS total FROM comments WHERE blog_id = :blog_id");
  $comment_count_stmt->bindParam(':blog_id', $blog['id'], PDO::PARAM_INT);
  $comment_count_stmt->execute();
  $comment_count = $comment_count_stmt->fetch(PDO::FETCH_ASSOC)['total'];








   
?>



<main id="main">

    <section class="single-post-content">
      <div class="container">
        <div class="row">
          <div class="col-md-9 post-content" data-aos="fade-up">

            <!-- ======= Single Post Content ======= -->
            <div class="single-post">
              <div class="post-meta"><span class="date"><?= htmlspecialchars($blog['category_name']) ?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($blog['insert_date'])) ?></span> <span class="mx-1">&bullet;</span> <span>by - <?= htmlspecialchars($blog['author_name']) ?></span></div>
              <h1 class="mb-5"><?= htmlspecialchars($blog['heading']) ?>.</h1>

               <figure class="my-4">
                <img src="<?= SITE_URL . $blog['thumb'] ?>" alt="<?= htmlspecialchars($blog['heading']) ?>" class="img-fluid">
                <!-- <figcaption>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo, odit? </figcaption> -->
              </figure>


              <!-- <p><span class="firstcharacter">L</span>orem ipsum dolor sit, amet consectetur adipisicing elit. Ratione officia sed, suscipit distinctio, numquam omnis quo fuga ipsam quis inventore voluptatum recusandae culpa, unde doloribus saepe labore alias voluptate expedita? Dicta delectus beatae explicabo odio voluptatibus quas, saepe qui aperiam autem obcaecati, illo et! Incidunt voluptas culpa neque repellat sint, accusamus beatae, cumque autem tempore quisquam quam eligendi harum debitis.</p> -->

             <p><?= ($blog['description']) ?></p>
              
               
             
            </div><!-- End Single Post Content -->

            <!-- ======= Comments ======= -->
            <div class="comments">
              <h5 class="comment-title py-4"><?= $comment_count ?> Comment<?= $comment_count != 1 ? 's' : '' ?></h5>

              <div id="comment-section">
                <?php if (!empty($comments)) { ?>
                    <?php foreach ($comments as $comment) { ?>
                        <div class="comment d-flex mb-4">
                            <div class="flex-shrink-0">
                                <div class="avatar avatar-sm rounded-circle">
                                    <img class="avatar-img" src="<?=SITE_URL?>user.png" alt="" class="img-fluid">
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-2 ms-sm-3">
                                <div class="comment-meta d-flex align-items-baseline">
                                    <h6 class="me-2"><?= htmlspecialchars($comment['name']) ?></h6>
                                    <span class="text-muted time-ago" data-time="<?= $comment['created_at']; ?>">
                                        <?= date("M j, Y", strtotime($comment['created_at'])) ?>
                                    </span>
 
                                </div>
                                <div class="comment-body">
                                    <?= nl2br(htmlspecialchars($comment['message'])) ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                <?php } else { ?>
                    <p class="text-muted">No comments yet. Be the first to comment!</p>
                <?php } ?>
            </div>





               
            </div><!-- End Comments -->

            <!-- ======= Comments Form ======= -->
            <!-- Comments Form -->
            <div class="row justify-content-center mt-5">
              <div class="col-lg-12">
                  <h5 class="comment-title">Leave a Comment</h5>

                  <!-- Success Alert (Hidden by Default) -->
                  <?php if (isset($_SESSION['comment_success'])): ?>
                      <p id="comment-success" class="text-danger">
                          <?= $_SESSION['comment_success']; ?>
                      </p>
                      <?php unset($_SESSION['comment_success']); ?>
                  <?php endif; ?>

                  <form method="POST" class="mt-3">
                      <div class="row">
                          <div class="col-lg-6 mb-3">
                              <label for="comment-name">Name</label>
                              <input type="text" class="form-control" name="name" required>
                          </div>
                          <div class="col-lg-6 mb-3">
                              <label for="comment-email">Email</label>
                              <input type="email" class="form-control" name="email" required>
                          </div>
                          <div class="col-12 mb-3">
                              <label for="comment-message">Message</label>
                              <textarea class="form-control" name="message" required cols="30" rows="5"></textarea>
                          </div>
                          <div class="col-12">
                              <input type="submit" class="btn btn-primary" name="submit_comment" value="Post Comment">
                          </div>
                      </div>
                  </form>
              </div>
          </div>

            <!-- End Comments Form -->

            <!-- End Comments Form -->

          </div>
          <div class="col-md-3">
            <!-- ======= Sidebar ======= -->

             <div class="aside-block mt-4 mt-lg-0">
              <h3 class="aside-title">Categories</h3>
              <ul class="aside-links list-unstyled">
                <li><a href="blog.php"><i class="bi bi-chevron-right"></i>All</a></li>
                  <?php foreach ($categories as $dd) { 
                      $salt = bin2hex(random_bytes(5)); // Generating a random salt
                      $encoded_id = base64_encode($salt . $dd['id']);
                  ?>
                      <li><a href="blog.php?category=<?=$encoded_id?>"><i class="bi bi-chevron-right"></i> <?=$dd['name']?></a></li>
                  <?php } ?>
              </ul>


            </div><!-- End Categories -->


             <div class="aside-block">

              <ul class="nav nav-pills custom-tab-nav mb-4" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="pills-popular-tab" data-bs-toggle="pill" data-bs-target="#pills-popular" type="button" role="tab" aria-controls="pills-popular" aria-selected="true">Trending Posts</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="pills-trending-tab" data-bs-toggle="pill" data-bs-target="#pills-trending" type="button" role="tab" aria-controls="pills-trending" aria-selected="false">Latest Posts</button>
                </li>
               
              </ul>

              <div class="tab-content" id="pills-tabContent">

                <!-- Popular -->
               <div class="tab-pane fade show active" id="pills-popular" role="tabpanel" aria-labelledby="pills-popular-tab">
                   
                   <?php
                      foreach ($trending_blogs as $tt) {
                   ?>

                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?=$tt['category_name']?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($tt['insert_date'])) ?></span></div>
                    <h2 class="mb-2"><a href="<?=SITE_URL?>blog-details.php?slug=<?=$tt['urlslug']?>"><?=$tt['heading']?></a></h2>
                    <span class="author mb-3 d-block"><?=$tt['author_name']?></span>
                  </div>

                  <?php
                      }
                   ?>

                    
                </div>  <!-- End Popular -->

                <!-- Trending -->
                <div class="tab-pane fade" id="pills-trending" role="tabpanel" aria-labelledby="pills-trending-tab">                   

                <?php
                      foreach ($latest_blogs as $ll){
                   ?>

                  <div class="post-entry-1 border-bottom">
                    <div class="post-meta"><span class="date"><?=$ll['category_name']?></span> <span class="mx-1">&bullet;</span> <span><?= date("M jS 'y", strtotime($ll['insert_date'])) ?></span></div>
                    <h2 class="mb-2"><a href="<?=SITE_URL?>blog-details.php?slug=<?=$ll['urlslug']?>"><?=$ll['heading']?></a></h2>
                    <span class="author mb-3 d-block"><?=$ll['author_name']?></span>
                  </div>

                  <?php
                      }
                   ?>                 

                </div> <!-- End Trending -->

                

              </div>
            </div>

            <div class="aside-block d-none">
              <h3 class="aside-title">Video</h3>
              <div class="video-post">
                <a href="https://www.youtube.com/watch?v=AiFfDjmd0jU" class="glightbox link-video">
                  <span class="bi-play-fill"></span>
                  <img src="<?=SITE_URL?>assets/img/post-landscape-5.jpg" alt="" class="img-fluid">
                </a>
              </div>
            </div><!-- End Video -->


            <div class="aside-block d-none">
              <h3 class="aside-title">Tags</h3>
              <ul class="aside-tags list-unstyled">
                <li><a href="category.html">Business</a></li>
                <li><a href="category.html">Culture</a></li>
                <li><a href="category.html">Sport</a></li>
                <li><a href="category.html">Food</a></li>
                <li><a href="category.html">Politics</a></li>
                <li><a href="category.html">Celebrity</a></li>
                <li><a href="category.html">Startups</a></li>
                <li><a href="category.html">Travel</a></li>
              </ul>
            </div><!-- End Tags -->

          </div>
        </div>
      </div>
    </section>
  </main><!-- End #main -->





















  

  <?php
  include'layout/footer.php';
?>

 



