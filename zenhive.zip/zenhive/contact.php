<?php
  session_start();
  include 'layout/header.php';

  // Generate new CAPTCHA numbers only when the page loads
  if (!isset($_SESSION['captcha_num1']) || !isset($_SESSION['captcha_num2'])) {
      $_SESSION['captcha_num1'] = rand(1, 9);
      $_SESSION['captcha_num2'] = rand(1, 9);
  }
  $captcha_correct = $_SESSION['captcha_num1'] + $_SESSION['captcha_num2'];

  $errorMsg = "";
  $successMsg = "";

  if (isset($_POST['submit'])) {
      $name = trim($_POST['name']);
      $email = trim($_POST['email']);
      $subject = trim($_POST['subject']);
      $message = trim($_POST['message']);
      $captchaInput = trim($_POST['captcha']);

      if ($captchaInput == $captcha_correct) {
          if (!empty($name) && !empty($email) && !empty($subject) && !empty($message)) {
              $stmt = $conn->prepare("INSERT INTO contact_leads (name, email, subject, message) VALUES (:name, :email, :subject, :message)");
              $stmt->execute([
                  ':name' => $name,
                  ':email' => $email,
                  ':subject' => $subject,
                  ':message' => $message
              ]);

              $successMsg = "Your message has been successfully sent!";
              
              // Reset CAPTCHA after successful submission
              $_SESSION['captcha_num1'] = rand(1, 9);
              $_SESSION['captcha_num2'] = rand(1, 9);

              // Refresh the page using JavaScript after submission
              // echo '<script>
                       
              //       </script>';
          }
      } else {
          $errorMsg = "Incorrect CAPTCHA. Try again.";
      }
  }
?>




  <main id="main">
    <section id="contact" class="contact mb-5">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 text-center mb-5">
            <h1 class="page-title">Contact us</h1>
          </div>
        </div>

        <div class="row gy-4">

          <div class="col-md-4">
            <div class="info-item">
              <i class="bi bi-geo-alt"></i>
              <h3>Address</h3>
              <address><?=COMPANY_ADDRESS ?></address>
            </div>
          </div><!-- End Info Item -->

          <div class="col-md-4">
            <div class="info-item info-item-borders">
              <i class="bi bi-phone"></i>
              <h3>Phone Number</h3>
              <p><a href="tel:+155895548855"><?=COMPANY_PHONE ?></a></p>
            </div>
          </div><!-- End Info Item -->

          <div class="col-md-4">
            <div class="info-item">
              <i class="bi bi-envelope"></i>
              <h3>Email</h3>
              <p><a href="mailto:info@example.com"><?=COMPANY_EMAIL ?></a></p>
            </div>
          </div><!-- End Info Item -->

        </div>

      <div class="form mt-5">
    <form method="post">
        <div class="row pb-3">
            <div class="form-group col-md-6">
                <input type="text" name="name" class="form-control" placeholder="Your Name" required>
            </div>
            <div class="form-group col-md-6 mt-3 mt-lg-0">
                <input type="email" class="form-control" name="email" placeholder="Your Email" required>
            </div>
        </div>
        <div class="form-group pb-3">
            <input type="text" class="form-control" name="subject" placeholder="Subject" required>
        </div>
        <div class="form-group mb-3">
            <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
        </div>

        <!-- CAPTCHA -->
        <div class="mb-3 ">
            <label class="me-2 mb-1 fw-bold">Solve: <?= $_SESSION['captcha_num1'] . " + " . $_SESSION['captcha_num2'] ?> = ?</label>
            <input type="number" name="captcha" class="form-control" required>
        </div>

        <?php if (!empty($errorMsg)): ?>
            <p class="text-danger fw-bold"><?= $errorMsg; ?></p>
        <?php endif; ?>

        <?php if (!empty($successMsg)): ?>
            <p class="text-success fw-bold"><?= $successMsg; ?></p>
        <?php endif; ?>

        <div class="text-center">
            <button type="submit" class="btn btn-dark" name="submit">Send Message</button>
        </div>
    </form>
</div>




      </div>
    </section>

  </main><!-- End #main -->

 <?php
  include'layout/footer.php';
?>